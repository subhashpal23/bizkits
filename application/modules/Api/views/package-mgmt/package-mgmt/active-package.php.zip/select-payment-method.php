<div class="dashboard-content-one">
                <!-- Breadcubs Area Start Here -->
                <div class="breadcrumbs-area">
                    <h3>Account Management</h3>
                    <ul>
                        <li>
                            <a href="<?php echo base_url();?>Affiliate">Home</a>
                        </li>
                        <li>Payment Method</li>
                    </ul>
                </div>
					<div class="row">
						 
						   <div class="col-md-4">
					  	   
							<div class="card card-flat border-top-success">
									<div class="card-body text-center">
									    <div class="text-left col-md-6">
                                                       <a  href="<?php echo site_url();?>Affiliate/Package/ewalletPayment">
                                                           <img src="<?php echo site_url();?>frontassets/ewallet.png">
                                                        </a>
                                                    </div>
						                            
					</div>
				
				</div>
			</div>
			
			<div class="col-md-4">
					  	   
							<div class="card card-flat border-top-success">
									<div class="card-body text-center">
									   
						                            <div class="text-left col-md-6">
                                                       <a  href="<?php echo site_url();?>Affiliate/Package/callPlisio/<?php echo $pkg_id;?>">
                                                           <img src="https://plisio.net/v2/images/logo-color.svg" style="width:100%"/>
                                                        </a>
                                                    </div>
					</div>
				
				</div>
			</div>
					</div>
				
				</div>