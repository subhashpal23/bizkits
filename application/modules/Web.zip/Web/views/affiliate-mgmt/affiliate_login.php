
			<!-- banner -->   
		<div class="web-banner">
            <div class="web-inner">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-12 col-xs-12 col-md-12 col-sm-12">
                            <div class="heading-inner contact-us-banner text-center">
                                <h1>Login</h1>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- banner -->
        <div class="web-contact">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="contact-div">
						
						<div class="row m-0 flex-div-grid">	
					
						
						
						<div class="col-lg-8 col-xs-12 col-sm-8 col-md-8 p-0">
										<div class="c-right">
								
                            <div class="tabbing-data text-center text-uppercase">
                                <ul class="list-inline">
                                    <li class="active"><a href="javascript:void(0);">Login</a></li>
                                </ul>
                            </div>	
							<div class="b-tabbing">
                                <div class="tab-content">
                                    <div id="stories" class="tab-pane fade in active">
                                        <div class="gallery-sec">
                                            <div class="row" style="margin:0;">
											<div class="contact-data m-b-30">
												
												<samp><?php echo $this->session->flashdata('res');?></samp>
												
											</div>
											<div class="step-form m-b-40">
											<form method="post" action="<?php echo base_url();?>login" id="school_contact">
													<div class="row">
														<div class="col-lg-6 col-xs-12 col-md-6 col-sm-6">
															<div class="form-group">
																<input id="schoolName" name="username" type="text" required="" placeholder="User Name" class="form-control" >
															</div>
														</div>
														<div class="col-lg-6 col-xs-12 col-md-6 col-sm-6">
															<div class="form-group">
																<input id="userName" name="password" type="password" required="" placeholder="Password" class="form-control" >
															</div>
														</div>
													</div>
													<div class="row">
														<div class="col-lg-12 col-xs-12 col-md-6 col-sm-6">
															<div class="theme-button text-uppercase">
															    
												<div class="btn-effect">
												    <input type="submit" data-animation="ripple" class="btn-default-page dnd" name="login"value="Login">
															</div>
														</div>
													</div>
												</form>

										</div>
											</div>
									</div>
						
						
						
						
						
						
                            
                                            
                                          
											
                                     
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
		</div>
		</div>
       <!-- footer -->
