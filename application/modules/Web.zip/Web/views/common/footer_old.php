<style>
    .product-cart-wrap .product-img-action-wrap .product-img-zoom a img {
        
        min-height: 144px;
        max-height: 144px;
    }
</style>
<footer class="main">
        
        <section class="featured section-padding">
            <div class="container">
                <div class="row">
                    <!--<div class="col-lg-1-5 col-md-4 col-12 col-sm-6 mb-md-4 mb-xl-0">
                        <div class="banner-left-icon d-flex align-items-center wow animate__animated animate__fadeInUp" data-wow-delay="0">
                            <div class="banner-icon">
                                <img src="<?php echo base_url();?>frontassets/imgs/theme/f1.png" alt="" />
                            </div>
                            <div class="banner-text">
                                <h3 class="icon-box-title">Best prices & offers</h3>
                                <p>Orders Rs.500 or more</p>
                            </div>
                        </div>
                    </div>-->
                    <div class="col-lg-1-5 col-md-4 col-12 col-sm-6">
                        <div class="banner-left-icon d-flex align-items-center wow animate__animated animate__fadeInUp" data-wow-delay=".1s">
                            <div class="banner-icon">
                                <img src="<?php echo base_url();?>frontassets/imgs/theme/f2.png" alt="" />
                            </div>
                            <div class="banner-text">
                                <h3 class="icon-box-title">Free delivery</h3>
                                <p>24/7 amazing services</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-1-5 col-md-4 col-12 col-sm-6">
                        <div class="banner-left-icon d-flex align-items-center wow animate__animated animate__fadeInUp" data-wow-delay=".2s">
                            <div class="banner-icon">
                                <img src="<?php echo base_url();?>frontassets/imgs/theme/f3.png" alt="" />
                            </div>
                            <div class="banner-text">
                                <h3 class="icon-box-title">Great daily deal</h3>
                                <p>When you sign up</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-1-5 col-md-4 col-12 col-sm-6">
                        <div class="banner-left-icon d-flex align-items-center wow animate__animated animate__fadeInUp" data-wow-delay=".3s">
                            <div class="banner-icon">
                                <img src="<?php echo base_url();?>frontassets/imgs/theme/f4.png" alt="" />
                            </div>
                            <div class="banner-text">
                                <h3 class="icon-box-title">Wide assortment</h3>
                                <p>Mega Discounts</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-1-5 col-md-4 col-12 col-sm-6">
                        <div class="banner-left-icon d-flex align-items-center wow animate__animated animate__fadeInUp" data-wow-delay=".4s">
                            <div class="banner-icon">
                                <img src="<?php echo base_url();?>frontassets/imgs/theme/f5.png" alt="" />
                            </div>
                            <div class="banner-text">
                                <h3 class="icon-box-title">Easy returns</h3>
                                <p style="color:#343333;">Within 30 days</p>
                            </div>
                        </div>
                    </div>
                   
                </div>
            </div>
        </section>
       
        <section class="section-padding footer-mid" style="background-color:#292424;">
            <div class="container pt-15 pb-20">
                <div class="row">
                    <div class="col">
                        <div class="widget-about font-md mb-md-3 mb-lg-3 mb-xl-0 wow animate__animated animate__fadeInUp" data-wow-delay="0">
                            <div class="logo mb-30">
                                <a href="index.html" class="mb-15"><img src="<?php echo base_url();?>frontassets/imgs/theme/logo.png" alt="logo" style="min-width: 50px !important;" /></a>
                               
                            </div>
                            <ul class="contact-infor" style="color:#fff;" >
                                <li><img src="<?php echo base_url();?>frontassets/imgs/location.png" alt="" /><span>B-427, Balaji Bhavan, Plot No.42A, Sector-11, <br>
								&ensp;&ensp;&ensp;CBD Belapur, Navi Mumbai-400614.</span></li>
                                <li><img src="<?php echo base_url();?>frontassets/imgs/call.png" alt="" /><span>(+91) - 8433661506</span></li>
                                <li><img src="<?php echo base_url();?>frontassets/imgs/email.png" alt="" /><span>customercare@adminza.in</span></li>
								 <img class="" src="<?php echo base_url();?>frontassets/imgs/theme/payment-method.png" alt="" />
                            </ul>
                        </div>
                    </div>
                
                    <div class="footer-link-widget col wow animate__animated animate__fadeInUp" data-wow-delay=".2s">
                        <h4 class="widget-title" style="color:#fff; font-size:18px;"></h4>
                        <ul class="footer-list mb-sm-5 mb-md-0">
                            <li><a href="#" style="color:#fff;">About Us</a></li>
                            <li><a href="#" style="color:#fff;">Privacy Policy</a></li>
                            <li><a href="#" style="color:#fff;">Terms &amp; Conditions</a></li>
                            <li><a href="#" style="color:#fff;">Contact Us</a></li>
                            <li><a href="#" style="color:#fff;">Careers</a></li>
							<li><a href="#" style="color:#fff;">Delivery Information</a></li>
							<li><a href="#" style="color:#fff;">Become a Vendor</a></li>
                          <li><a href="#"style="color:#fff;">Promotions</a></li>
						  <li><a href="#" style="color:#fff;">Support Center</a></li>
                        </ul>
                    </div>
					 <div class="footer-link-widget col wow animate__animated animate__fadeInUp" data-wow-delay=".2s">
                        <h4 class="widget-title" style="color:#fff; font-size:18px;"></h4>
                        <ul class="footer-list mb-sm-5 mb-md-0">
                            
							<li><a href="#" style="color:#fff;">Software & App development </a></li>
							<li><a href="#" style="color:#fff;">Hardware installations </a></li>
							<li><a href="#" style="color:#fff;">Backup Solutions</a></li>
							<li><a href="#"style="color:#fff;">Professional premise deep cleaning</a></li>
							<li><a href="#" style="color:#fff;">Web Site Design Solutions </a></li>
							<li><a href="#" style="color:#fff;">Digital Marketing Solutions </a></li>
							<li><a href="#" style="color:#fff;">Email Services </a></li>
							<li><a href="#" style="color:#fff;"> Label & sticker printing</a></li>
							
							
                        </ul>
                    </div>
                    <div class="footer-link-widget col wow animate__animated animate__fadeInUp" data-wow-delay=".3s">
                        <h4 class="widget-title" style="color:#fff; font-size:18px;"></h4>
                        <ul class="footer-list mb-sm-5 mb-md-0">
						<li><a href="#" style="color:#fff;">Smart access control</a></li>
							<li><a href="#" style="color:#fff;"> Cloud based security </a></li> 
                            <li><a href="#" style="color:#fff;"> Wireless CCTV</a></li>
							<li><a href="#" style="color:#fff;"> Buy & Sale an office</a></li>
							<li><a href="#"style="color:#fff;"> Repair Maintenance Services</a></li>
							<li><a href="#"style="color:#fff;"> Pantry management</a></li>
							<li><a href="#" style="color:#fff;"> Corporate Gifting</a></li>
							<li><a href="#" style="color:#fff;">Fit outs & Interiors as per requirement</a></li> 
							<li><a href="#" style="color:#fff;">Refurbished office furniture</a></li>							
							
                        </ul>
                    </div>
                    
                   
                </div>
        </section>
        <div class="container pb-30 wow animate__animated animate__fadeInUp" data-wow-delay="0" style="background-color:#022a40;">
            <div class="row align-items-center">
                <div class="col-12 mb-30">
                    <div class="footer-bottom" ></div>
                </div>
               
                
				 <div class="col-xl-6 col-lg-6 col-md-6">
                    <p class="font-sm mb-0" style="color:#fff;"> &copy; 2025, Copyright by Adminza. All Right Reserved. <!-- <strong class="text-brand">Nest</strong> - HTML Ecommerce Template <br />All rights reserved --></p>
                </div>
                <div class="col-xl-4 col-lg-6 col-md-6 text-end d-none d-md-block">
                    <div class="mobile-social-icon">
                        <h6 style="color:#fff;">Follow Us</h6>
                        <a href="#"><img src="<?php echo base_url();?>frontassets/imgs/theme/icons/icon-facebook-white.svg" alt="" /></a>
                     
                        <a href="#"><img src="<?php echo base_url();?>frontassets/imgs/theme/icons/icon-instagram-white.svg" alt="" /></a>
                        <a href="#"><img src="<?php echo base_url();?>frontassets/imgs/theme/icons/icon-pinterest-white.svg" alt="" /></a>
                       
                    </div>
                    <!-- <p class="font-sm">Up to 15% discount on your first subscribe</p> -->
                </div>
            </div>
        </div>
    </footer>
    <!-- Preloader Start -->
    
    <!-- Vendor JS-->
    <script src="<?php echo base_url();?>frontassets/js/vendor/modernizr-3.6.0.min.js"></script>
    <script src="<?php echo base_url();?>frontassets/js/vendor/jquery-3.6.0.min.js"></script>
    <script src="<?php echo base_url();?>frontassets/js/vendor/jquery-migrate-3.3.0.min.js"></script>
    <script src="<?php echo base_url();?>frontassets/js/vendor/bootstrap.bundle.min.js"></script>
    <script src="<?php echo base_url();?>frontassets/js/plugins/slick.js"></script>
    <script src="<?php echo base_url();?>frontassets/js/plugins/jquery.syotimer.min.js"></script>
    <script src="<?php echo base_url();?>frontassets/js/plugins/waypoints.js"></script>
    <script src="<?php echo base_url();?>frontassets/js/plugins/wow.js"></script>
    <script src="<?php echo base_url();?>frontassets/js/plugins/perfect-scrollbar.js"></script>
    <script src="<?php echo base_url();?>frontassets/js/plugins/magnific-popup.js"></script>
    <script src="<?php echo base_url();?>frontassets/js/plugins/select2.min.js"></script>
    <script src="<?php echo base_url();?>frontassets/js/plugins/counterup.js"></script>
    <script src="<?php echo base_url();?>frontassets/js/plugins/jquery.countdown.min.js"></script>
    <script src="<?php echo base_url();?>frontassets/js/plugins/images-loaded.js"></script>
    <script src="<?php echo base_url();?>frontassets/js/plugins/isotope.js"></script>
    <script src="<?php echo base_url();?>frontassets/js/plugins/scrollup.js"></script>
    <script src="<?php echo base_url();?>frontassets/js/plugins/jquery.vticker-min.js"></script>
    <script src="<?php echo base_url();?>frontassets/js/plugins/jquery.theia.sticky.js"></script>
    <script src="<?php echo base_url();?>frontassets/js/plugins/jquery.elevatezoom.js"></script>
    <!-- Template  JS -->
    <script src="<?php echo base_url();?>frontassets/js/main.js?v=6.0"></script>
    <script src="<?php echo base_url();?>frontassets/js/shop.js?v=6.0"></script>
    <style>
        #search_results{
            position: absolute;
            background: rgb(255, 255, 255);
            width: 71%;
            border: 1px solid rgb(204, 204, 204);
            right: 0;
            top: 51px;
            z-index: 11;
            max-height: 213px;
            overflow: auto;
        }
        .modal.show .modal-dialog{
            width:500px;
        }
        .custom-modal .modal-dialog .modal-content{
            padding:0px;
        }
        #enquiryForm label{
            color:#000;
        }
        #enquiryForm .form-control{
            border:1px solid #999999;
        }
        @media only screen and (max-width: 767px) {
          .modal.show .modal-dialog{
            width:365px;
        }
        }
    </style>
    <style>
        .product-price{
            /*display:none;*/
        }
        #modalContainer {
        	background-color:rgba(0, 0, 0, 0.3);
        	position:absolute;
        	width:100%;
        	height:100%;
        	top:0px;
        	left:0px;
        	z-index:10000;
        	background-image:url(tp.png); /* required by MSIE to prevent actions on lower z-index elements */
        }
        
        #alertBox {
        	position:relative;
        	width:300px;
        	min-height:100px;
        	margin-top:50px;
        	border:1px solid #666;
        	/*background-color:#fff;*/
        	background-color:#890224;
        	
        	background-repeat:no-repeat;
        	background-position:20px 30px;
        }
        
        #modalContainer > #alertBox {
        	position:fixed;
        }
        
        #alertBox h1 {
        	margin:0;
        	font:bold 0.9em verdana,arial;
        	background-color:#890224;
        	color:#FFF;
        	border-bottom:1px solid #000;
        	padding:2px 0 2px 5px;
        }
        
        #alertBox p {
        	font:1em verdana,arial;
        	height:50px;
        	padding-left:5px;
        	margin-left:55px;
        	color:#FFF;
        }
        
        #alertBox #closeBtn {
        	display:block;
        	position:relative;
        	margin:5px auto;
        	padding:7px;
        	border:0 none;
        	width:70px;
        	font:0.7em verdana,arial;
        	text-transform:uppercase;
        	text-align:center;
        	color:#890224;
        	background-color:#b9edd4;
        	border-radius: 3px;
        	text-decoration:none;
        }
        
        .#closeBtn:hover {
            background-color: #890224;
            color: #fff;
            transform: translateY(-3px);
            box-shadow: 5px 5px 15px rgba(0, 0, 0, 0.05);
        }
        /*#closeBtn {
            position: relative;
            display:block;
            padding: 6px 20px 6px 20px;
            border-radius: 4px;
            background-color: #DEF9EC;
            font-size: 14px;
            font-weight: 700;
        }*/
        /* unrelated styles */
        
        #mContainer {
        	position:relative;
        	width:600px;
        	margin:auto;
        	padding:5px;
        	border-top:2px solid #000;
        	border-bottom:2px solid #000;
        	font:0.7em verdana,arial;
        }
        
        h1,h2 {
        	margin:0;
        	padding:4px;
        	font:bold 1.5em verdana;
        	border-bottom:1px solid #000;
        }
        
        code {
        	font-size:1.2em;
        	color:#069;
        }
        
        #credits {
        	position:relative;
        	margin:25px auto 0px auto;
        	width:350px; 
        	font:0.7em verdana;
        	border-top:1px solid #000;
        	border-bottom:1px solid #000;
        	height:90px;
        	padding-top:4px;
        }
        
        #credits img {
        	float:left;
        	margin:5px 10px 5px 0px;
        	border:1px solid #000000;
        	width:80px;
        	height:79px;
        }
        
        .important {
        	background-color:#F5FCC8;
        	padding:2px;
        }
        
        code span {
        	color:green;
        }
    </style>    
    <script>
        document.addEventListener('click', function(event) {
            const form = document.querySelector('form');
            const searchResults = document.getElementById('search_query');
            
            // Check if the click is outside the form
            if (!form.contains(event.target)) {
                searchResults.value = ''; 
                liveSearch();
            }
        });
        
       function clearSearch() {
            
            //const searchInput = document.getElementById('search_query');
            liveSearch();
           // searchInput.value = ''; // Clear search text
        }
       $(document).ready(function () {
            window.liveSearch = function () { // Define globally
                let query = $("#search_query").val();
                let category = $("#category").val();
        
                if (query.length < 2) {
                    $("#search_results").hide();
                    return;
                }
        
                $.ajax({
                    url: "<?= base_url('Web/fetch_products') ?>",
                    method: "POST",
                    data: { query: query, category: category },
                    success: function (data) {
                        $("#search_results").html(data).show();
                    }
                });
            };
        });
        var ALERT_TITLE = "Message!";
        var ALERT_BUTTON_TEXT = "Ok";
        
        function createCustomAlert(txt) {
        	d = document;
        
        	if(d.getElementById("modalContainer")) return;
        
        	mObj = d.getElementsByTagName("body")[0].appendChild(d.createElement("div"));
        	mObj.id = "modalContainer";
        	mObj.style.height = d.documentElement.scrollHeight + "px";
        	
        	alertObj = mObj.appendChild(d.createElement("div"));
        	alertObj.id = "alertBox";
        	if(d.all && !window.opera) alertObj.style.top = document.documentElement.scrollTop + "px";
        	alertObj.style.left = (d.documentElement.scrollWidth - alertObj.offsetWidth)/2 + "px";
        	alertObj.style.visiblity="visible";
        
        	h1 = alertObj.appendChild(d.createElement("h1"));
        	h1.appendChild(d.createTextNode(ALERT_TITLE));
        
        	msg = alertObj.appendChild(d.createElement("p"));
        	//msg.appendChild(d.createTextNode(txt));
        	msg.innerHTML = txt;
        
        	btn = alertObj.appendChild(d.createElement("a"));
        	btn.id = "closeBtn";
        	btn.class= 'add';
        	btn.appendChild(d.createTextNode(ALERT_BUTTON_TEXT));
        	btn.href = "#";
        	btn.focus();
        	btn.onclick = function() { removeCustomAlert();return false; }
        
        	alertObj.style.display = "block";
        	
        }
        function removeCustomAlert() {
        	document.getElementsByTagName("body")[0].removeChild(document.getElementById("modalContainer"));
        }        
        function addcartproducts(id) {
          // Get the quantity value from the input field
            var qty = $('.addcart').val();
            
            if (isNaN(qty) || qty < 1) {
                createCustomAlert("Quantity must be at least 1.");
                return;
            }
    
        
            // Perform AJAX request
            $.ajax({
                type: 'POST',
                url: '<?php echo site_url();?>Web/Cart/addToCartProducts/' + id + "/" + qty,
                data: { product_id: id, requestType: 'addCart' },
                async: false,
                beforeSend: function () {
                    // Optional: Add a loader or disable the button
                },
                success: function (res) {
                    console.log(res);
                    var res1 = JSON.parse(res);
                    $('.carttotal').html(res1.total);
                    $('.totalcost').html(res1.total_cost);
                    loadcartitems();
                    createCustomAlert("Product added successfully.");
                    $("#scrollUp").click();
                    setTimeout(function() {
                        location.reload();
                    }, 2000);
                },
                complete: function () {
                    // Optional: Remove loader or enable the button
                }
            });
        }
       function loadcartitems()
        {
            //alert(id);
            var qty = 1;
            $.ajax({
               type:'POST',
               url:'<?php echo site_url();?>Web/Cart/loadCartItems',
               data: {requestType:'addCart'},
               async:false,
               beforeSend: function () {
                    
                  },
               success:function(res){
                console.log(res);
                //alert(res);
                 
                 $('.cartplist').html(res);
                 
               },//end success
              complete: function () {
           
                } 
          });//end ajax
            
        }
        function removefromcartproducts(id)
        {
            //alert(id);
            $.ajax({
               type:'POST',
               url:'<?php echo site_url();?>Web/Cart/removeItemFromCartProducts/'+id+'/'+'/Removed',
               data: {product_id:id,requestType:'addCart'},
               async:false,
               beforeSend: function () {
                    
                  },
               success:function(res){
                console.log(res);
                var res1=JSON.parse(res);
                $('.carttotal').html(res1.total);
                $('.totalcost').html(res1.total_cost);
                 loadcartitems();
                 createCustomAlert("Product removed successfully.");
                 $("#scrollUp").click();
                 setTimeout(function() {
                    location.reload();
                }, 2000);
               },//end success
              complete: function () {
           
                } 
          });//end ajax
            
        }   
        function updatecart(id)
        {
            //alert(id);
            var qty = $('#quantity_'+id).val();
            $.ajax({
               type:'POST',
               url:'<?php echo site_url();?>Web/Cart/updateQtyProducts/'+id+'/'+qty,
               data: {product_id:id,qty:qty,requestType:'addCart'},
               async:false,
               beforeSend: function () {
                    
                  },
               success:function(res){
                console.log(res);
                var res1=JSON.parse(res);
                $('.carttotal').html(res1.total);
                $('.totalcost').html(res1.total_cost);
                $('.totaldiscount').html(res1.total_discount);
                $('.gtotalcost').html(res1.grand_total_cost);
                 loadcartitems();
                 loadcartpage();
                 createCustomAlert("Cart updated successfully.");
                 $("#scrollUp").click();
                 setTimeout(function() {
                    location.reload();
                }, 2000);
               },//end success
              complete: function () {
           
                } 
          });//end ajax
            
        }
        function loadcartpage()
        {
            //alert(id);
            var qty = 1;
            $.ajax({
               type:'POST',
               url:'<?php echo site_url();?>Web/Cart/loadCartPage',
               data: {requestType:'addCart'},
               async:false,
               beforeSend: function () {
                    
                  },
               success:function(res){
                console.log(res);
                //alert(res);
                 
                 $('#shocartpage').html(res);
                 
               },//end success
              complete: function () {
           
                } 
          });//end ajax
            
        }    
        function removefromcartproduct(id)
        {
            //alert(id);
            $.ajax({
               type:'POST',
               url:'<?php echo site_url();?>Web/Cart/removeItemFromCartProducts/'+id+'/'+'/Removed',
               data: {product_id:id,requestType:'addCart'},
               async:false,
               beforeSend: function () {
                    
                  },
               success:function(res){
                console.log(res);
                var res1=JSON.parse(res);
                $('.carttotal').html(res1.total);
                $('.totalcost').html(res1.total_cost);
                $('.totaldiscount').html(res1.total_discount);
                $('.gtotalcost').html(res1.grand_total_cost);
                 loadcartitems();
                 loadcartpage();
                 createCustomAlert("Product removed successfully.");
                 $("#scrollUp").click();
                  setTimeout(function() {
                    location.reload();
                }, 2000);
               },//end success
              complete: function () {
           
                } 
          });//end ajax
            
        }      
        function clearCartItems()
        {
            $.ajax({
               type:'POST',
               url:'<?php echo site_url();?>Web/Cart/clearCart',
               data: {requestType:'addCart'},
               async:false,
               beforeSend: function () {
                    
                  },
               success:function(res){
                 createCustomAlert("All Product removed successfully.");
                 $("#scrollUp").click();
                  setTimeout(function() {
                    location.reload();
                }, 2000);
               },//end success
              complete: function () {
           
                } 
          });//end ajax
            
        }   


    </script>
</body>

</html>