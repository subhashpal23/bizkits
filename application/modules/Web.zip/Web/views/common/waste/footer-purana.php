<div class="footer_area footer_four bg_dark_3">
         <!--===============spacing==============-->
           <div class="pd_top_80"></div>
         <!--===============spacing==============-->
         <div class="footer_widgets_wrap">
            <div class="auto-container">
               <div class="row">
                  <div class="col-xl-4 col-lg-6 col-md-6 col-sm-12 mb-sm-5 mb-md-5 mb-lg-5 mb-xl-0">
                     <div class="footer_contact_form light_c type_one">
                        <div class="form_box_foo">
                           <h2> Contact Us</h2>
                           <div class="contact_form_shortcode">
                              <div role="form" class="wpcf7" id="wpcf7-f1763-o1" lang="en-US" dir="ltr">
                                 <div class="screen-reader-response">
                                    <p role="status" aria-live="polite" aria-atomic="true"></p>
                                    <ul></ul>
                                 </div>
                                 <form action="#" method="post"  class="wpcf7-form init" novalidate="novalidate" data-status="init">
                                   
                                    <p><label><br>
                                          <span class="wpcf7-form-control-wrap" data-name="your-name"><input type="text"
                                                name="your-name" value="" size="40"
                                                class="wpcf7-form-control wpcf7-text wpcf7-validates-as-required"
                                                aria-required="true" aria-invalid="false"
                                                placeholder="Enter Your Name"></span> </label>
                                    </p>
                                    <p><label><br>
                                          <span class="wpcf7-form-control-wrap" data-name="your-email"><input
                                                type="email" name="your-email" value="" size="40"
                                                class="wpcf7-form-control wpcf7-text wpcf7-email wpcf7-validates-as-required wpcf7-validates-as-email"
                                                aria-required="true" aria-invalid="false"
                                                placeholder="Enter Your Mail"></span> </label>
                                    </p>
                                    <p><label><br>
                                          <span class="wpcf7-form-control-wrap" data-name="your-subject"><input
                                                type="text" name="your-subject" value="" size="40"
                                                class="wpcf7-form-control wpcf7-text wpcf7-validates-as-required"
                                                aria-required="true" aria-invalid="false"
                                                placeholder="Enter Your Subject"></span> </label>
                                    </p>
                                    <p> 
                                       <input type="submit" value="Submit" class="wpcf7-form-control has-spinner wpcf7-submit"> 
                                    </p>
                              
                                 </form>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
                  <div class="col-xl-4 col-lg-6 col-md-6 col-sm-12 mb-sm-5 mb-md-5 mb-lg-5 mb-xl-0">
                     <!--===============spacing==============-->
                        <div class="pd_top_30"></div>
                     <!--===============spacing==============-->
                     <div class="footer_widgets wid_tit style_two">
                        <div class="fo_wid_title">
                           <h2>Informations</h2>
                        </div>
                     </div>
                     <div class="footer_widgets clearfix navigation_foo light_color style_three">
                        <div class="navigation_foo_box">
                           <div class="navigation_foo_inner">
                              <div class="left">
                                 <div class="menu-information-container">
                                    <ul>
                                       <li><a href="#">Home</a></li>
                                       <li><a href="#">About Us</a></li>
                                       <li><a href="#">Compensation Plan</a></li>
                                       <li><a href="#">Contact Us</a></li>
                                       
                                    </ul>
                                 </div>
                              </div>
                              <div class="right">
                                 <div class="menu-essentials-container">
                                    <ul>
                                       <li><a href="#">Return Policy</a></li>
                                       <li><a href="#">Client Support</a></li>
                                       <li><a href="#">Privacy Policy</a></li>
                                       <li><a href="#">Terms of Use</a></li>
                                       
                                    </ul>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
                  <div class="col-xl-4 col-lg-6 col-md-6 col-sm-12">
                     <!--===============spacing==============-->
                        <div class="pd_top_30"></div>
                     <!--===============spacing==============-->
                     <div class="footer_widgets wid_tit style_two">
                        <div class="fo_wid_title">
                           <h2>Subscribe Us Today</h2>
                        </div>
                     </div>
                     <div class="footer_widgets foo_subscribe light_color style_one">
                        <div class="item_subscribe with_text">
                           <p>Subscribe Us &amp; Recive Our Offers and Updates i Your Inbox Directly.</p>
                           <div class="shortcodes">
                              
                              <form class="mc4wp-form" method="post" data-name="Subscibe">
                                 <div class="mc4wp-form-fields">
                                    <input type="email" name="EMAIL" placeholder="Your email address" required="">
                                    <input type="submit" value="Sign up">
                                 </div>
                              </form>

                           </div>
                           <p>* We do not share your email id</p>
                        </div>
                     </div>
                     <div class="social_media_v_one">
                        <ul>
                           <li>
                              <a href="#"> <span class="fa fa-facebook"></span>
                                 <small>facebook</small>
                              </a>
                           </li>
                           <li>
                              <a href="#"> <span class="fa fa-twitter"></span>
                                 <small>twitter</small>
                              </a>
                           </li>
                           <li>
                              <a href="#"> <span class="fa fa-skype"></span>
                                 <small>skype</small>
                              </a>
                           </li>
                           <li>
                              <a href="#"> <span class="fa fa-instagram"></span>
                                 <small>instagram</small>
                              </a>
                           </li>
                        </ul>
                     </div>
                  </div>
               </div>
            </div>
         </div>
         <!--===============spacing==============-->
            <div class="pd_bottom_70"></div>
         <!--===============spacing==============-->
         <div class="footer-copyright bg_dark_1">
            <!--===============spacing==============-->
               <div class="pd_top_15"></div>
            <!--===============spacing==============-->
            <div class="auto-container">
               <div class="footer_copy_right style_two">
                  <div class="row">
                     <div class="col-lg-6 col-md-12 mb-2 mb-lg-0 mb-xl-0">
                        <div class="footer_copy_content color_white">
                           © 2024 <a href="#" class="color_white">i3Empire.</a> All Rights
                           Reserved.
                        </div>
                     </div>
                     <div class="col-lg-6 col-md-12">
                        <div class="footer_copy_content_right text-md-end">
                           <div class="nav_link_v_one">
                              <ul>
                                 
                                 <li>
                                    <a href="#" target="_blank" rel="nofollow" class="color_white">Private Policy</a>
                                 </li>
                              </ul>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
            <!--===============spacing==============-->
               <div class="pd_bottom_10"></div>
            <!--===============spacing==============-->
         </div>
      </div>
      <!---==============footer end =================-->
   <!---==============mobile menu =================-->
   <div class="crt_mobile_menu">
      <div class="menu-backdrop"></div>
      <nav class="menu-box">
         <div class="close-btn"><i class="icon-close"></i></div>
         <form role="search" method="get" action="#">
            <input type="search" class="search" placeholder="Search..." value="" name="s" title="Search" />
            <button type="submit" class="sch_btn"> <i class="icon-search"></i></button>
         </form>
         <div class="menu-outer">
            <!--Here Menu Will Come Automatically Via Javascript / Same Menu as in Header-->
         </div>
      </nav>
   </div>
   <!---==============mobile menu end =================-->
   <!---==============search popup =================-->
   <div id="search-popup" class="search-popup">
      <div class="close-search"><i class="fa fa-times"></i></div>
      <div class="popup-inner">
         <div class="overlay-layer"></div>
         <div class="search-form">
            <fieldset>
               <form role="search" method="get" action="#">
                  <input type="search" class="search" placeholder="Search..." value="" name="s" title="Search" />
                  <button type="submit" class="sch_btn"> <i class="icon-search"></i></button>
               </form>
            </fieldset>
         </div>
      </div>
   </div>
   <!---==============search popup end =================-->
   <!---==============modal popup =================-->
   <div class="modal_popup one">
      <div class="modal-popup-inner">
         <div class="close-modal"><i class="fa fa-times"></i></div>
         <div class="modal_box">
            <div class="row">
               <div class="col-lg-5 col-md-12 form_inner">
                  <div class="form_content">
               
                         
                        <form class="contact-form" method="post" action="sendemail.php">
                           <p>
                              <label> Your name<br />
                                <input type="text" name="name" value="" size="40"   aria-required="true" aria-invalid="false" placeholder="Enter Your Name" /> 
                                <br />
                                 <i class="fa fa-user"></i><br />
                              </label>
                           </p>
                           <p><label> Your email<br />
                               <input type="email" name="email" value="" size="40" aria-required="true" aria-invalid="false"  placeholder="Enter Your Email" />
                               <br />
                              <i class="fa fa-envelope"></i><br />
                              </label>
                           </p>
                           <p>
                              <label> Subject<br />
                                <input type="text" name="subject" value="" size="40" aria-required="true" aria-invalid="false"  placeholder="Enter Your Subject" /> 
                                <br />
                                 <i class="fa fa-folder"></i><br />
                              </label>
                           </p>
                           <p>
                              <label> Your message (optional)<br />
                                 <textarea name="message"  cols="40" rows="10" class="wpcf7-form-control wpcf7-textarea"  aria-invalid="false" placeholder="Enter Your Message"></textarea> 
                                 <br />
                                 <i class="fa fa-comments"></i><br />
                              </label>
                           </p>
                           <p><input type="submit" value="Submit" /></p>
                        
                        </form>
                 
                  </div>
               </div>
               <div class="col-lg-7 col-md-12 about_company_inner">
                  <div class="abt_content">
                     <div class="logo">
                        <img src="<?php echo base_url();?>frontassets/images/logo-default.png" alt="img" class="company_logo_modal">
                     </div>
                     <div class="text">
                        <p> The great explorer of the truth, the master-builder of human happiness no one rejects
                           dislikes avoids pleasure itself because it is pleasure but because know who do not those
                           how to pursue pleasures rationally encounter consequences that are extremely painful
                           desires to obtain.</p>
                        <a href="#">Read More</a>
                     </div>
                     <div class="post_contet_modal">
                        <h2> Latest News</h2>
                        <div class="post_enable">
                           <div class="modal_post_grid">
                              <a href="blog-single.html">
                                 <img width="852" height="812" src="<?php echo base_url();?>frontassets/images/blog/blog-image-9.jpg"
                                    class="main_img wp-post-image" alt="img" />
                              </a>
                           </div>
                           <div class="modal_post_grid">
                              <a href="blog-single.html">
                                 <img width="852" height="812" src="<?php echo base_url();?>frontassets/images/blog/blog-image-8.jpg"
                                    class="main_img wp-post-image" alt="img" />
                              </a>
                           </div>
                           <div class="modal_post_grid">
                              <a href="blog-single.html">
                                 <img width="852" height="812" src="<?php echo base_url();?>frontassets/images/blog/blog-image-7.jpg"
                                    class="main_img wp-post-image" alt="img" />
                              </a>
                           </div>
                           <div class="modal_post_grid">
                              <a href="blog-single.html">
                                 <img width="852" height="812" src="<?php echo base_url();?>frontassets/images/blog/blog-image-6.jpg"
                                    class="main_img wp-post-image" alt="img" />
                              </a>
                           </div>
                           <div class="modal_post_grid">
                              <a href="blog-single.html">
                                 <img width="852" height="812" src="<?php echo base_url();?>frontassets/images/blog/blog-image-5.jpg"
                                    class="main_img wp-post-image" alt="img" />
                              </a>
                           </div>
                        </div>
                     </div>
                     <div class="copright">
                        © 2024 I3Empire. All Rights Reserved.
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>
   <!---==============modal popup end=================-->
   <!---==============cart=================-->
   <div class="side_bar_cart" id="mini_cart">
      <div class="cart_overlay"></div>
      <div class="cart_right_conten">
         <div class="close">
            <div class="close_btn_mini"><i class="icon-close"></i></div>
         </div>
         <div class="cart_content_box">
            <div class="contnet_cart_box">
               <div class="widget_shopping_cart_content">
                  <p class="woocommerce-mini-cart__empty-message">No products in the cart.</p>
               </div>
            </div>
         </div>
      </div>
   </div>
   <!---==============cart=================-->
 
</div>
<!-- Back to top with progress indicator-->
<div class="prgoress_indicator">
   <svg class="progress-circle svg-content" width="100%" height="100%" viewBox="-1 -1 102 102">
      <path d="M50,1 a49,49 0 0,1 0,98 a49,49 0 0,1 0,-98" />
   </svg>
</div>
   <!---========================== javascript ==========================-->
   <script type='text/javascript' src='<?php echo base_url();?>frontassets/js/jquery-3.6.0.min.js'></script>
   <script type='text/javascript' src='<?php echo base_url();?>frontassets/js/bootstrap.min.js'></script>
   <script type='text/javascript' src='<?php echo base_url();?>frontassets/js/jquery.fancybox.js'></script>
   <script type='text/javascript' src='<?php echo base_url();?>frontassets/js/jQuery.style.switcher.min.js'></script>
   <script type='text/javascript' src='<?php echo base_url();?>frontassets/js/jquery.flexslider-min.js'></script>
   <script type='text/javascript' src='<?php echo base_url();?>frontassets/js/color-scheme.js'></script>
   <script type='text/javascript' src='<?php echo base_url();?>frontassets/js/owl.js'></script>
   <script type='text/javascript' src='<?php echo base_url();?>frontassets/js/swiper.min.js'></script>
   <script type='text/javascript' src='<?php echo base_url();?>frontassets/js/isotope.min.js'></script>
   <script type='text/javascript' src='<?php echo base_url();?>frontassets/js/countdown.js'></script>
   <script type='text/javascript' src='<?php echo base_url();?>frontassets/js/simpleParallax.min.js'></script>
   <script type='text/javascript' src='<?php echo base_url();?>frontassets/js/appear.js'></script>
   <script type='text/javascript' src='<?php echo base_url();?>frontassets/js/jquery.countTo.js'></script>
   <script type='text/javascript' src='<?php echo base_url();?>frontassets/js/sharer.js'></script>
   <script type='text/javascript' src='<?php echo base_url();?>frontassets/js/validation.js'></script>
   <!-- map script -->
   <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyA-CE0deH3Jhj6GN4YvdCFZS7DpbXexzGU"></script>
   <script src="<?php echo base_url();?>frontassets/js/gmaps.js"></script>
   <script src="<?php echo base_url();?>frontassets/js/map-helper.js"></script>
   <!-- main-js -->
   <script type='text/javascript' src='<?php echo base_url();?>frontassets/js/creote-extension.js'></script>
   <!---========================== javascript ==========================-->
</body>
</html>
<script>
function checkusername(str)
{
    str=str.replace(/ /g,'');
    //alert(str);
    $("#username").val(str);
}

function check_sponsor(sponsor_id)
{
	 //var platform=$("#platform").val();
	 if(sponsor_id=='')
     {
		 
         $("#check_sponsor").children().remove();
         $("#check_sponsor").append('<div>Please enter referral ID!</div>').css({
                   'font-weight': 'bold',
                   'color': 'red',
                   'margin': '0',
                   'padding': '0',
                   'float': 'left',
                   'font-size': '13px'
                  });//end css
			  
     }
	 
     else 
     {
         //$("#check_sponsor").append(loader_image);
         //var platform=$("#platform").val();
		 
		 $.ajax({
               type:'POST',
               url:'<?php echo site_url();?>Web/isUserNameExists',
               data: {username:sponsor_id,requestType:'sponsor'},
               async:false,
               beforeSend: function () {
                    //$("#load").css("display", "block");
                    //$("#overlay").fadeIn(300);
                  },
               success:function(res){
               	
                 $("#check_sponsor").children().remove();
                 if(res.exist!='1')
                 {
                  $("#check_sponsor").append('<div class="text-danger">Sorry Referral does not exists!</div>').css({
                   'font-weight': 'bold',
                   'color': 'red',
                   'margin': '0',
                   'padding': '0',
                   'float': 'left',
                   'font-size': '14px'
                  });//end css
                  //$("#sponsor_id").focus();
                 }//end if
                 else 
                 {
                  $("#check_sponsor").append('<div class="text-success">'+res.username+' Exist</div>').css({
                   'font-weight': 'bold',
                   'color': 'green',
                   'margin': '0',
                   'padding': '0',
                   'float': 'left',
                   'font-size': '14px'
                  });//end css
                 }
               },//end success
               complete: function () {
                    //$("#load").css("display", "none");
                    //$("#overlay").fadeOut(300);
                }

          });//end ajax
     }
}//end function

//$(document).ready(function(){alert("call")});
function check_user(upline_id)
{
    var platform=$("#platform").val();
	 if(upline_id=='')
     {
         $("#check_user").children().remove();
         $("#check_user").append('<div>Please enter upline ID!</div>').css({
                   'font-weight': 'bold',
                   'color': 'red',
                   'margin': '0',
                   'padding': '0',
                   'float': 'left',
                   'font-size': '13px'
                  });//end css
     }
	 else if(platform=='')
	 {
			$("#valid_platform").children().remove();
			$("#valid_platform").append('<div>Please select package first!</div>').css({
                   'font-weight': 'bold',
                   'color': 'red',
                   'margin': '0',
                   'padding': '0',
                   'float': 'left',
                   'font-size': '14px'
                  });//end css
		$("#upline_id").val(null);
		$("#platform").focus();		  
		return false;			  
	 }
     else 
     {
         //$("#check_sponsor").append(loader_image);
         var platform=$("#platform").val();
		 
		 $.ajax({
               type:'POST',
               url:'<?php echo site_url();?>Web/isUserNameExists',
               data: {username:upline_id,requestType:'upline','pkg_id':platform},
               async:false,
               beforeSend: function () {
                    $("#overlay").fadeIn(300);
                  },
               success:function(res){
                 $("#check_user").children().remove();
                 if(res.exist!='1')
                 {
                  $("#check_user").append('<div class="text-danger">Sorry Upline does not exists!</div>').css({
                   'font-weight': 'bold',
                   'color': 'red',
                   'margin': '0',
                   'padding': '0',
                   'float': 'left',
                   'font-size': '14px'
                  });//end css
                  //$("#sponsor_id").focus();
                 }//end if
                 else 
                 {
                  $("#check_user").append('<div class="text-success">'+res.username+' Exist</div>').css({
                   'font-weight': 'bold',
                   'color': 'green',
                   'margin': '0',
                   'padding': '0',
                   'float': 'left',
                   'font-size': '14px'
                  });//end css
                 }
               },//end success
               complete: function () {
                    $("#overlay").fadeOut(300);
                }
          });//end ajax
     }
}
function check_username(username)
{
     //var loader_image='<img src="<?php echo site_url();?>front_<?php echo base_url();?>frontassets/images/loader.gif" width="auto">';
     if(username=='')
     {
         $("#check_username").children().remove();
         $("#check_username").append('<div>Please enter login Id!</div>').css({
                   'font-weight': 'bold',
                   'color': 'red',
                   'margin': '0',
                   'padding': '0',
                   'float': 'left',
                   'font-size': '13px'
                  });//end css
                  //$("#sponsor_id").focus();
     }
     else 
     {
           //$("#check_username").append(loader_image);
           $.ajax({
               type:'POST',
               url:'<?php echo site_url();?>Web/isUserNameExists',
               data: {username:username,requestType:'new_user'},
               async:false,
               beforeSend: function () {
                    //$("#load").css("display", "block");
                    $("#overlay").fadeIn(300);
                  },
               success:function(res){
                 $("#check_username").children().remove();
                 if(res.exist=='1')
                 {
                  
                   $("#check_username").append('<div class="text-danger">Sorry '+username+' already exists!</div>').css({
                   'font-weight': 'bold',
                   'color': 'red',
                   'margin': '0',
                   'padding': '0',
                   'float': 'left',
                   'font-size': '14px'
                  });//end css
                 }//end if
                 else 
                 {
                  $("#check_username").append('<div class="text-success">'+username+' available!</div>').css({
                   'font-weight': 'bold',
                   'color': 'green',
                   'margin': '0',
                   'padding': '0',
                   'float': 'left',
                   'font-size': '14px'
                  });//end css
                 }
               },//end success
              complete: function () {
                    //$("#load").css("display", "none");
                    $("#overlay").fadeOut(300);
                } 
          });//end ajax
     }
}//end function

function check_idno(username)
{
     //var loader_image='<img src="<?php echo site_url();?>front_<?php echo base_url();?>frontassets/images/loader.gif" width="auto">';
    var minLength = 10;
    var maxLength = 10;
    var charLength = username.length;
     if(username=='')
     {
         $("#check_idno").children().remove();
         $("#check_idno").html('<div>Please enter pan card!</div>').css({
                   'font-weight': 'bold',
                   'color': 'red',
                   'margin': '0',
                   'padding': '0',
                   'float': 'left',
                   'font-size': '13px'
                  });//end css
                  //$("#sponsor_id").focus();
     }
     else if(charLength < minLength){
        $('#check_idno').html('Length is short, minimum '+minLength+' required.').css({
                   'font-weight': 'bold',
                   'color': 'red',
                   'margin': '0',
                   'padding': '0',
                   'float': 'left',
                   'font-size': '13px'
                  });
    }else if(charLength > maxLength){
        $('#check_idno').html('Length is not valid, maximum '+maxLength+' allowed.').css({
                   'font-weight': 'bold',
                   'color': 'red',
                   'margin': '0',
                   'padding': '0',
                   'float': 'left',
                   'font-size': '13px'
                  });
        $('#idno').val(char.substring(0, maxLength));
    }
    
     else 
     {
           //$("#check_username").append(loader_image);
           $.ajax({
               type:'POST',
               url:'<?php echo site_url();?>Web/isIdNoExists',
               data: {username:username,requestType:'new_user'},
               async:false,
               beforeSend: function () {
                    //$("#load").css("display", "block");
                    $("#overlay").fadeIn(300);
                  },
               success:function(res){
                 $("#check_idno").children().remove();
                 if(res.exist=='1')
                 {
                  
                   $("#check_idno").html('<div>Sorry '+username+' already exists!</div>').css({
                   'font-weight': 'bold',
                   'color': 'red',
                   'margin': '0',
                   'padding': '0',
                   'float': 'left',
                   'font-size': '14px'
                  });//end css
                 }//end if
                 else 
                 {
                  $("#check_idno").html('<div>'+username+' available!</div>').css({
                   'font-weight': 'bold',
                   'color': 'green',
                   'margin': '0',
                   'padding': '0',
                   'float': 'left',
                   'font-size': '14px'
                  });//end css
                 }
               },//end success
              complete: function () {
                    //$("#load").css("display", "none");
                   $("#overlay").fadeOut(300);
                } 
          });//end ajax
     }
}//end function

//check_aadharno
function check_aadharno(username)
{
     //var loader_image='<img src="<?php echo site_url();?>front_<?php echo base_url();?>frontassets/images/loader.gif" width="auto">';
     // check username should be 12 length
    var minLength = 12;
    var maxLength = 12;
    var charLength = username.length;
    if(username=='')
     {
        $("#check_aadharno").children().remove();
        $("#check_aadharno").html('<div>Please enter Aadhar No!</div>').css({
                   'font-weight': 'bold',
                   'color': 'red',
                   'margin': '0',
                   'padding': '0',
                   'float': 'left',
                   'font-size': '13px'
                  });//end css
        //$("#sponsor_id").focus();
     }
     else if(charLength < minLength){
        $('#check_aadharno').html('Length is short, minimum '+minLength+' required.').css({
                   'font-weight': 'bold',
                   'color': 'red',
                   'margin': '0',
                   'padding': '0',
                   'float': 'left',
                   'font-size': '13px'
                  });
    }else if(charLength > maxLength){
        $('#check_aadharno').html('Length is not valid, maximum '+maxLength+' allowed.').css({
                   'font-weight': 'bold',
                   'color': 'red',
                   'margin': '0',
                   'padding': '0',
                   'float': 'left',
                   'font-size': '13px'
                  });
        $('#aadharno').val(char.substring(0, maxLength));
    }
     
     else 
     {
        //$("#check_username").append(loader_image);
       $.ajax({
           type:'POST',
           url:'<?php echo site_url();?>front/isAadharNoExists',
           data: {username:username,requestType:'new_user'},
           async:false,
           beforeSend: function () {
                //$("#load").css("display", "block");
                $.loader("on", '<?php echo site_url();?>admin_<?php echo base_url();?>frontassets/images/default.svg');
              },
           success:function(res){
             $("#check_aadharno").children().remove();
             if(res.exist=='1')
             {
               $("#check_aadharno").html('<div>Sorry '+username+' already exists!</div>').css({
               'font-weight': 'bold',
               'color': 'red',
               'margin': '0',
               'padding': '0',
               'float': 'left',
               'font-size': '14px'
              });//end css
             }//end if
             else 
             {
              $("#check_aadharno").html('<div>'+username+' available!</div>').css({
               'font-weight': 'bold',
               'color': 'green',
               'margin': '0',
               'padding': '0',
               'float': 'left',
               'font-size': '14px'
              });//end css
             }
           },//end success
          complete: function () {
                //$("#load").css("display", "none");
                $.loader("off", '<?php echo site_url();?>admin_<?php echo base_url();?>frontassets/images/default.svg');
            } 
      });//end ajax
     }
}//end function
//$(document).ready(function(){alert("call")});

function showpasserror(value)
{
    var password=$("#passwords").val();
          var confirm_password=$("#confirm_password").val();
          if(password!=confirm_password)
          {
               $("#valid_confirm_password").text("Confirm Password does not match!").css({'color':'red','font-weight':'bold'});
          }
          else
          {
               $("#valid_confirm_password").text("");
          }
}
     
     
     ////
     $("#btn").click(function(){
          
          var password=$("#passwords").val();
          var confirm_password=$("#confirm_password").val();
          if(password!=confirm_password)
          {
               $("#valid_confirm_password").text("Confirm Password does not match!").css({'color':'red','font-weight':'bold'});
               $("#confirm_password").focus();
               return false;
          }
          
          if(!$("#term_cond").is(':checked'))
          {
               $("#valid_term_cond").text("Accept Terms & Condition!").css({'color':'red','font-weight':'bold'});
               //$("#term_cond").focus();
               return false;
          }
          return true;
     });
     $("#platform").change(function(){
		if($(this).val()!='')
		{
			$("#valid_platform").children().remove();
		}
	});

function myFunction(inco,icon) {
  var x = document.getElementById(inco);
  var i = document.getElementById(icon);
  if (x.type === "password") {
    x.type = "text";
    i.type = "text";
    
  } else {
    x.type = "password";
    i.type = "password";
    
  }
}

function checkPasswordMatch() {
    var password = $("#passwords").val();
    var confirmPassword = $("#confirm_password").val();
    if (password != confirmPassword)
    $("#valid_confirm_password").html("<font color='red'>Login Password Do Not Match!</font>");
    else
    $("#valid_confirm_password").html("<font color='green'>Passwords match.</font>");
    }
    
    function checkPasswordMatch1() {
    var password1 = $("#passwords1").val();
    var confirmPassword1 = $("#confirm_password1").val();
    if (password1 != confirmPassword1)
    $("#valid_confirm_password1").html("<font color='red'>Transaction Password Do Not Match!");
    else
    $("#valid_confirm_password1").html("<font color='green'>Passwords match.</font>");
    }
</script>
<script language="javascript">print_country("country");</script>