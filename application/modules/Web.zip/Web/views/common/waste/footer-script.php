<script type="text/javascript">
         var c = document.body.className;
         c = c.replace(/woocommerce-no-js/, 'woocommerce-js');
         document.body.className = c;
      </script>
      <script type="text/javascript">
         function revslider_showDoubleJqueryError(sliderID) {
         	var errorMessage = "Revolution Slider Error: You have some jquery.js library include that comes after the revolution files js include.";
         	errorMessage += "<br> This includes make eliminates the revolution slider libraries, and make it not work.";
         	errorMessage += "<br><br> To fix it you can:<br>&nbsp;&nbsp;&nbsp; 1. In the Slider Settings -> Troubleshooting set option:  <strong><b>Put JS Includes To Body</b></strong> option to true.";
         	errorMessage += "<br>&nbsp;&nbsp;&nbsp; 2. Find the double jquery.js include and remove it.";
         	errorMessage = "<span style='font-size:16px;color:#BC0C06;'>" + errorMessage + "</span>";
         		jQuery(sliderID).show().html(errorMessage);
         }
      </script>
      <link rel='stylesheet' id='cubeportfolio-css'  href='<?php echo base_url();?>front_assets/css/cubeportfolio.min.css' type='text/css' media='all' />
      <link rel='stylesheet' id='responsive-tabs-css'  href='<?php echo base_url();?>front_assets/css/responsive-tabs.css' type='text/css' media='all' />
      <link rel='stylesheet' id='smk-accordion-css'  href='<?php echo base_url();?>front_assets/css/smk-accordion.css' type='text/css' media='all' />
      <script type='text/javascript'>
         /* <![CDATA[ */
         var wpcf7 = {"apiSettings":{"root":"http:\/\/pexrwp.joomlastars.co.in\/wp-json\/contact-form-7\/v1","namespace":"contact-form-7\/v1"},"recaptcha":{"messages":{"empty":"Please verify that you are not a robot."}}};
         /* ]]> */
      </script>
      <script type='text/javascript' src='<?php echo base_url();?>front_assets/js/scripts.js'></script>
      <script type='text/javascript' src='<?php echo base_url();?>front_assets/js/jquery.blockUI.min.js'></script>
      <script type='text/javascript' src='<?php echo base_url();?>front_assets/js/js.cookie.min.js'></script>
      <script type='text/javascript'>
         /* <![CDATA[ */
         var woocommerce_params = {"ajax_url":"\/wp-admin\/admin-ajax.php","wc_ajax_url":"\/?wc-ajax=%%endpoint%%"};
         /* ]]> */
      </script>
      <script type='text/javascript' src='<?php echo base_url();?>front_assets/js/woocommerce.min.js'></script>
      <script type='text/javascript'>
         /* <![CDATA[ */
         var wc_cart_fragments_params = {"ajax_url":"\/wp-admin\/admin-ajax.php","wc_ajax_url":"\/?wc-ajax=%%endpoint%%","cart_hash_key":"wc_cart_hash_6374a6b1878bb3b4febed8dceab29659","fragment_name":"wc_fragments_6374a6b1878bb3b4febed8dceab29659"};
         /* ]]> */
      </script>
      <script type='text/javascript' src='<?php echo base_url();?>front_assets/js/cart-fragments.min.js'></script>
      <script type='text/javascript' src='<?php echo base_url();?>front_assets/js/bootstrap.min.js'></script>
      <script type='text/javascript' src='<?php echo base_url();?>front_assets/js/main.js'></script>
      <script type='text/javascript' src='<?php echo base_url();?>front_assets/js/owl.carousel.js'></script>
      <script type='text/javascript' src='<?php echo base_url();?>front_assets/js/custom.js'></script>
      <script type='text/javascript' src='<?php echo base_url();?>front_assets/js/functions.js'></script>
      <script type='text/javascript' src='<?php echo base_url();?>front_assets/js/loaders.js'></script>
      <script type='text/javascript' src='<?php echo base_url();?>front_assets/js/parallax-background.min.js'></script>
      <script type='text/javascript' src='<?php echo base_url();?>front_assets/js/parallax-custom.js'></script>
      <script type='text/javascript' src='<?php echo base_url();?>front_assets/js/wp-embed.min.js'></script>
      <script type='text/javascript' src='<?php echo base_url();?>front_assets/js/js_composer_front.min.js'></script>
      <script type='text/javascript' src='<?php echo base_url();?>front_assets/js/jquery.cubeportfolio.min.js'></script>
      <script type='text/javascript' src='<?php echo base_url();?>front_assets/js/main-mosaic3.js'></script>
      <script type='text/javascript' src='<?php echo base_url();?>front_assets/js/responsive-tabs.js'></script>
      <script type='text/javascript' src='<?php echo base_url();?>front_assets/js/smk-accordion.js'></script>
      <script type='text/javascript' src='<?php echo base_url();?>front_assets/js/custom2.js'></script>