<div class="breadcumb-wrapper" data-bg-src="<?php echo base_url();?>frontassets/images/bg.jpg">
            <div class="container">
                <div class="breadcumb-content">
                    <h1 class="breadcumb-title" style="color:#fff;">About Us</h1>
                    <ul class="breadcumb-menu">
                        <li>
                            <a href="<?php echo base_url();?>" style="color:#fff;">Home</a>
                        </li>
                        <li style="color:#fff;">About Us</li>
                    </ul>
                </div>
            </div>
        </div>











        <div class="overflow-hidden overflow-hidden space" id="about-sec">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-xl-6 mb-30 mb-xl-0">
                        <div class="img-box1">
                            <div class="img1">
                                <img src="<?php echo base_url();?>frontassets/images/about/1.jpg" alt="About">
                            </div>
                            <div class="img2">
                                <img src="<?php echo base_url();?>frontassets/images/about/2.jpg" alt="Image">
                            </div>
                            <div class="img2">
                                <img src="<?php echo base_url();?>frontassets/images/about/3.jpg" alt="Image">
                            </div>
                            <div class="shape1 movingX">
                                <img src="<?php echo base_url();?>frontassets/images/about/about_1_3.png" alt="Image">
                            </div>
                            
                            
                        </div>
                    </div>
                    <div class="col-xl-6">
                        <div class="ps-xxl-5 ps-xl-2 ms-xl-1 text-center text-xl-start">
                            <div class="title-area mb-32">
                                <span class="sub-title">
                                    About Dream Buider
                                </span>
                                <h2 class="sec-title">Welcome to Dream Buider</h2>
                                <p class="sec-text">Dream Buider africa is an enterprise development company. <br>
                                        That invest in creating values, creating opportunities and creating wealth wuth interest in technology.</p>

                                    <h4 class="sec-title">Our Vision</h4>
                                    <p class="sec-text">To see Africans transform and become a world class solution provider in the health and welness sector, where everyone has the opportunity to make their dreams and reality.</p>

                                        <h4 class="sec-title">Our Mission</h4>
                                    <p class="sec-text">To deliver exellence natural organic products and services to our customers and empower the dreams of our distributers,which help to translate into wealth.
</p>
                            </div>
                           
                            
                        </div>
                    </div>
                </div>
            </div>
        </div>







        <!--<section class="why-sec3 space" data-bg-src="<?php echo base_url();?>frontassets/images/bg2.jpg">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-lg-6 col-md-8">
                        <div class="title-area text-center">
                         
                            <h2 class="sec-title text-white">OUR CORE VALUES</h2>
                        </div>
                    </div>
                </div>
                <div class="row gx-0 justify-content-between">
                    <div class="col-sm-auto">
                        <div class="why-feature-left">
                            <div class="why-feature">
                                <div class="box-icon">
                                    <img src="assets/img/icon/why_feature_1.svg" alt="">
                                </div>
                                <div class="media-body">
                                    <div class="box-title">Partnership: </div>
                                    <p class="box-text">We believe in partnership, from product quality to customer experience.</p>
                                </div>
                            </div>
                            <div class="why-feature">
                                <div class="box-icon">
                                    <img src="assets/img/icon/why_feature_2.svg" alt="">
                                </div>
                                <div class="media-body">
                                    <div class="box-title">Genuineness:</div>
                                    <p class="box-text">We believe in good products delivery.</p>
                                </div>
                            </div>
                            <div class="why-feature">
                                <div class="box-icon">
                                    <img src="assets/img/icon/why_feature_3.svg" alt="">
                                </div>
                                <div class="media-body">
                                    <div class="box-title">Excellence:</div>
                                    <p class="box-text">We strive for excellence in everything we do, from product quality to customer experience.</p>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-auto d-none d-lg-block">
                        <div class="img-box4 mt-0">
                            <img src="<?php echo base_url();?>frontassets/images/core.png" alt="Why">
                        </div>
                    </div>
                    
                    <div class="col-sm-auto">
                        <div class="why-feature-right">
                            <div class="why-feature">
                                <div class="box-icon">
                                    <img src="assets/img/icon/why_feature_4.svg" alt="">
                                </div>
                                <div class="media-body">
                                    <div class="box-title">Accountability:</div>
                                    <p class="box-text">A core value of a strong workplace.</p>
                                </div>
                            </div>
                            <div class="why-feature">
                                <div class="box-icon">
                                    <img src="assets/img/icon/why_feature_5.svg" alt="">
                                </div>
                                <div class="media-body">
                                    <div class="box-title">Creativity: </div>
                                    <p class="box-text">We empower individuals to take charge of their health and wealth, creating a pathway to a fulfilled life.</p>
                                </div>
                            </div>
                            <div class="why-feature">
                                <div class="box-icon">
                                    <img src="assets/img/icon/why_feature_6.svg" alt="">
                                </div>
                                
                        </div>
                    </div>
                </div>
            </div>
        </section> <br>
        <section class="why-sec3 space" data-bg-src="<?php echo base_url();?>frontassets/images/bg2.jpg">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-lg-6 col-md-8">
                        <div class="title-area text-center">
                         
                            <h2 class="sec-title text-white">OUR ECO-SYSTEM</h2>
                        </div>
                    </div>
                </div>
                <div class="row gx-0 justify-content-between">
                    <div class="col-sm-auto">
                        <div class="why-feature-left">
                            <div class="why-feature">
                                <div class="box-icon">
                                    <img src="assets/img/icon/why_feature_1.svg" alt="">
                                </div>
                                <div class="media-body">
                                    <div class="box-title">Health and Wellness: </div>
                                    <p class="box-text">Health and Wellness refers to a holistic approach to achieving and maintaining a state of physical, mental, and emotional well-being. It encompasses practices, products, and services designed to improve overall quality of life by promoting healthy habits, preventing illness, and managing stress.</p>
                                </div>
                            </div>
                            <div class="why-feature">
                                <div class="box-icon">
                                    <img src="assets/img/icon/why_feature_2.svg" alt="">
                                </div>
                                <div class="media-body">
                                    <div class="box-title">Agri-Business:</div>
                                    <p class="box-text">Agri-Business (short for Agricultural Business) refers to the industries and activities involved in the production, processing, and distribution of agricultural products.</p>
                                </div>
                            </div>
                            <div class="why-feature">
                                <div class="box-icon">
                                    <img src="assets/img/icon/why_feature_3.svg" alt="">
                                </div>
                                <div class="media-body">
                                    <div class="box-title">Real-Estate:</div>
                                    <p class="box-text">Real Estate refers to property consisting of land and the buildings on it, along with its natural resources such as water, minerals, and vegetation.</p>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-auto d-none d-lg-block">
                        <div class="img-box4 mt-0">
                            <img src="<?php echo base_url();?>frontassets/images/core.png" alt="Why">
                        </div>
                    </div>
                    
                    <div class="col-sm-auto">
                        <div class="why-feature-right">
                            <div class="why-feature">
                                <div class="box-icon">
                                    <img src="assets/img/icon/why_feature_4.svg" alt="">
                                </div>
                                <div class="media-body">
                                    <div class="box-title">E-commerce:</div>
                                    <p class="box-text">E-commerce (short for electronic commerce) refers to the buying and selling of goods and services over the internet.</p>
                                </div>
                            </div>
                            <div class="why-feature">
                                <div class="box-icon">
                                    <img src="assets/img/icon/why_feature_5.svg" alt="">
                                </div>
                                <div class="media-body">
                                    <div class="box-title">Travels and Tours: </div>
                                    <p class="box-text">Travels and Tours refers to a business or service dedicated to organizing and managing travel arrangements and tourism experiences for individuals or groups.</p>
                                </div>
                            </div>
                            <div class="why-feature">
                                <div class="box-icon">
                                    <img src="assets/img/icon/why_feature_6.svg" alt="">
                                </div>
                                <div class="media-body">
                                    <div class="box-title">Trainings & Consultancy: </div>
                                    <p class="box-text">Trainings & Consultancy refers to professional services focused on providing education, skill development, and expert advice to individuals, organizations, or businesses.</p>
                                </div>
                        </div>
                    </div>
                </div>
            </div>
        </section> <br>-->
        
        <div class="overflow-hidden space">
            <div class="container">
        <h1>DreamBuilders Africa - Business Plan</h1>
        <section>
            <h2>About Us</h2>
            <p>DreamBuilders Africa is a subsidiary of DreamBuilders Concept, registered with the Corporate Affairs Commission (Registration Number: 3463255) in 2021. We are committed to creating values, opportunities, and wealth with a special interest in technology.</p>
        </section>

        <section>
            <h2>Our Core Values</h2>
            <ul>
                <li>Partnership</li>
                <li>Genuineness</li>
                <li>Excellence</li>
                <li>Accountability</li>
                <li>Creativity</li>
            </ul>
        </section>

        <section>
            <h2>Our Eco-System</h2>
            <ul>
                <li>Health and Wellness</li>
                <li>Agri-Business</li>
                <li>Real-Estate</li>
                <li>E-commerce</li>
                <li>Travels and Tours</li>
                <li>Trainings & Consultancy</li>
            </ul>
        </section>
        </div>
        </div>