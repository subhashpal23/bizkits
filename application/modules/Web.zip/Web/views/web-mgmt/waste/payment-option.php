<div class="breadcumb-wrapper" data-bg-src="<?php echo base_url();?>frontassets/images/bg.jpg">
            <div class="container">
                <div class="breadcumb-content">
                    <h1 class="breadcumb-title" style="color:#fff;">Payment Methods</h1>
                    <ul class="breadcumb-menu">
                        <li>
                            <a href="<?php echo base_url();?>" style="color:#fff;">Home</a>
                        </li>
                        <li style="color:#fff;">Payment Methods</li>
                    </ul>
                </div>
            </div>
        </div>











        <div class="overflow-hidden overflow-hidden space" id="about-sec">
            <div class="container">
                <div class="row align-items-center">
                    <!--<div class="col-xl-6 mb-30 mb-xl-0">
                        <div class="col-md-3">
                                       <a onclick="return bankWirePaymentConfirm();" href="<?php echo site_url();?>bank-wire-payment"><img src="<?php echo base_url();?>frontassets/images/bank-transfer.png" style="width:100%"/></a>
                                     </div>
                    </div>-->
                   <div class="col-xl-6 mb-30 mb-xl-0">
                        <div class="col-md-3">
                                       <a  href="<?php echo site_url();?>ewallet-payment"><img src="<?php echo base_url();?>frontassets/ewallet.png" style="width:100%"/></a>
                                     </div>
                    </div>
                </div>
            </div>
        </div>


