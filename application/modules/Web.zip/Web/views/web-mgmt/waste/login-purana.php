<div id="wrapper_full"  class="content_all_warpper">
            <!----page-header----->
            <!----page-CONTENT----->
            <div id="content" class="site-content ">
               <div class="container">
                  <div class="row default_row">
                      <div class="col-xl-3">&nbsp;</div>
                     <div class="col-xl-6 col-lg-12 col-md-12 col-sm-12 col-xs-12 mb-5 mb-lg-5 mb-xl-0">
                              <section class="contact_form_box_all type_two">
                                 <div class="contact_form_box_inner">
                                    <div class="contact_form_shortcode">
                                       <div class="heading">
                                          <h2>Login</h2>
                                       </div>
                                       <div class="_form">
                                          <div role="form" class="wpcf7">
                                            
                                             <form action="<?php echo base_url();?>Web/login" method="post" class="wpcf7-form init">
                                              
                                                <p><label> Username<br>
                                                   <span class="wpcf7-form-control-wrap your-name"><input type="text" name="username" value="" size="40" class="wpcf7-form-control wpcf7-text wpcf7-validates-as-required" aria-required="true" aria-invalid="false" placeholder="Enter Username"></span><br>
                                                   <!--<i class="fa fa-user"></i>--><br>
                                                   </label>
                                                </p>
                                                <p><label> Password<br>
                                                   <span class="wpcf7-form-control-wrap your-email"><input type="password" name="password" value="" size="40" class="wpcf7-form-control wpcf7-text wpcf7-email wpcf7-validates-as-required wpcf7-validates-as-email" aria-required="true" aria-invalid="false" placeholder="Enter Password"></span><br>
                                                   <!--<i class="fa fa-settings"></i>--><br>
                                                   </label>
                                                </p>
                                                <!--<p><label> Subject<br>
                                                   <span class="wpcf7-form-control-wrap your-subject"><input type="text" name="your-subject" value="" size="40" class="wpcf7-form-control wpcf7-text wpcf7-validates-as-required" aria-required="true" aria-invalid="false" placeholder="Enter Your Subject"></span><br>
                                                   <i class="fa fa-folder"></i><br>
                                                   </label>
                                                </p>
                                                <p><label> Your message (optional)<br>
                                                   <span class="wpcf7-form-control-wrap your-message"><textarea name="your-message" cols="40" rows="10" class="wpcf7-form-control wpcf7-textarea" aria-invalid="false" placeholder="Enter Your Message"></textarea></span><br>
                                                   <i class="fa fa-comments"></i><br>
                                                   </label>
                                                </p>-->
                                                <p><input type="submit" name="login" value="Login" class="wpcf7-form-control has-spinner wpcf7-submit">
                                                </p>
                                    
                                             </form>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                              </section>
                           </div>
                           <div class="col-xl-3">&nbsp;</div>
                  </div>
               </div>
            </div>
         </div>
      </div>
      <!-- Back to top with progress indicator-->
      <div class="prgoress_indicator">
         <svg class="progress-circle svg-content" width="100%" height="100%" viewBox="-1 -1 102 102">
            <path d="M50,1 a49,49 0 0,1 0,98 a49,49 0 0,1 0,-98" />
         </svg>
      </div>