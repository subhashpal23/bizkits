<!-- slider-area-start -->
		<div class="slider-area">
			<div class="slider-active owl-carousel">
				<div class="single-slider ptb-150 bg-opacity" style="background-image:url(<?php echo base_url();?>webassets/img/slider/1.jpg)">
					<div class="container">
						<div class="slider-text">
							<h3>Join our Affiliate Program</h3>
							<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque vel volutpat felis, eu condimentum massa.<br> Pellentesque mollis eros vel mattis tempor. Aliquam eu efficitur enim</p>
							<a href="<?php echo base_url();?>Web/affiliate-signup">Sign-Up</a>&nbsp;&nbsp;<a href="<?php echo base_url();?>Web/affiliate-login">Login</a>
						</div>
					</div>
				</div>
				<!--<div class="single-slider ptb-150 bg-opacity" style="background-image:url(<?php echo base_url();?>webassets/img/slider/2.jpg)">-->
				<!--	<div class="container">-->
				<!--		<div class="slider-text text-center">-->
				<!--			<h3>Education For Everyone</h3>-->
				<!--			<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque vel volutpat felis, eu condimentum massa.<br> Pellentesque mollis eros vel mattis tempor. Aliquam eu efficitur enim</p>-->
				<!--			<a href="#">Read More</a>-->
				<!--		</div>-->
				<!--	</div>-->
				<!--</div>-->
				<!--<div class="single-slider ptb-150 bg-opacity" style="background-image:url(<?php echo base_url();?>webassets/img/slider/1.jpg)">-->
				<!--	<div class="container">-->
				<!--		<div class="slider-text">-->
				<!--			<h3>Education For Everyone</h3>-->
				<!--			<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque vel volutpat felis, eu condimentum massa.<br> Pellentesque mollis eros vel mattis tempor. Aliquam eu efficitur enim</p>-->
				<!--			<a href="#">Read More</a>-->
				<!--		</div>-->
				<!--	</div>-->
				<!--</div>-->
			</div>
		</div>
		<!-- slider-area-end -->

		<!-- features-area-start -->
		<div class="features-area pt-80 pb-50">
			<div class="container">
			    <div class="section-title text-center">
					<h3>Make Big Money</h3>
				</div>
				<div class="row">
					<div class="col-lg-4 col-md-6">
						<div class="single-features text-center mb-30">
							<div class="icon-box">
								<i class="fa fa-paper-plane"></i>
							</div>
							<h5>Top-notch tracking</h5>
							
						</div>
					</div>
					<div class="col-lg-4 col-md-6">
						<div class="single-features text-center mb-30">
							<div class="icon-box">
								<i class="fa fa-check-square"></i>
							</div>
							<h5>Regular Payouts</h5>
						
						</div>
					</div>
					<div class="col-lg-4 col-md-6">
						<div class="single-features text-center mb-30">
							<div class="icon-box">
								<i class="fa fa-plane"></i>
							</div>
							<h5>Zero Investment</h5>
						
						</div>
					</div>
				</div>
			</div>
		</div>
		<!-- features-area-end -->
		<!-- features-area-start -->
		<div class="features-area pt-80 pb-50">
			<div class="container">
			    <div class="section-title text-center">
					<h3>Become an Affiliate in 3 Easy Steps</h3>
				</div>
				<div class="row">
					<div class="col-lg-4 col-md-6">
						<div class="single-features text-center mb-30">
							<div class="icon-box">
								<i class="fa fa-paper-plane"></i>
							</div>
							<h5>1. Signup</h5>
							<p>It’s fast & easy. Absolutely no setup necessary. Just fill in the details and you’re ready.</p>
						</div>
					</div>
					<div class="col-lg-4 col-md-6">
						<div class="single-features text-center mb-30">
							<div class="icon-box">
								<i class="fa fa-check-square"></i>
							</div>
							<h5>2. Promote</h5>
							<p>Use beautiful banners that we provide to promote . You drive visitors, we take care of the rest.</p>
						
						</div>
					</div>
					<div class="col-lg-4 col-md-6">
						<div class="single-features text-center mb-30">
							<div class="icon-box">
								<i class="fa fa-plane"></i>
							</div>
							<h5>3. Earn BIG</h5>
						    <p>The more you promote the more you earn. You get paid for every successful conversion that takes place via your affiliate link.</p>
						</div>
					</div>
				</div>
			</div>
		</div>
		<!-- features-area-end -->
		<!-- features-area-start -->
		<div class="features-area pt-80 pb-50">
			<div class="container">
			    <div class="section-title text-center">
					<h3>Seriously Big Commissions</h3>
				</div>
				<table class="table table-sm">
                  <thead>
                    <tr>
                      <th scope="col">Product Category</th>
                      <th scope="col">Commission Per Qualified Sale</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td>New Referal</td>
                      <td><span style="color:orange">10%</span> of each referal</td>
                    </tr>
                    <tr>
                      <td>Study Material</td>
                      <td><span style="color:orange">10%</span> of each sale</td>
                    </tr>
                    
                  </tbody>
                </table>
			</div>
		</div>
		<!-- features-area-end -->
	<div class="features-area pt-80 pb-50">	
	    <div class="container">
		    <div class="faq-wrapper">
  
  <input id="question1" type="checkbox" name="toggle" class="question" />
  <label for="question1">
    <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADwAAABMCAYAAAAx3tSzAAAACXBIWXMAAC4jAAAuIwF4pT92AAAKT2lDQ1BQaG90b3Nob3AgSUNDIHByb2ZpbGUAAHjanVNnVFPpFj333vRCS4iAlEtvUhUIIFJCi4AUkSYqIQkQSoghodkVUcERRUUEG8igiAOOjoCMFVEsDIoK2AfkIaKOg6OIisr74Xuja9a89+bN/rXXPues852zzwfACAyWSDNRNYAMqUIeEeCDx8TG4eQuQIEKJHAAEAizZCFz/SMBAPh+PDwrIsAHvgABeNMLCADATZvAMByH/w/qQplcAYCEAcB0kThLCIAUAEB6jkKmAEBGAYCdmCZTAKAEAGDLY2LjAFAtAGAnf+bTAICd+Jl7AQBblCEVAaCRACATZYhEAGg7AKzPVopFAFgwABRmS8Q5ANgtADBJV2ZIALC3AMDOEAuyAAgMADBRiIUpAAR7AGDIIyN4AISZABRG8lc88SuuEOcqAAB4mbI8uSQ5RYFbCC1xB1dXLh4ozkkXKxQ2YQJhmkAuwnmZGTKBNA/g88wAAKCRFRHgg/P9eM4Ors7ONo62Dl8t6r8G/yJiYuP+5c+rcEAAAOF0ftH+LC+zGoA7BoBt/qIl7gRoXgugdfeLZrIPQLUAoOnaV/Nw+H48PEWhkLnZ2eXk5NhKxEJbYcpXff5nwl/AV/1s+X48/Pf14L7iJIEyXYFHBPjgwsz0TKUcz5IJhGLc5o9H/LcL//wd0yLESWK5WCoU41EScY5EmozzMqUiiUKSKcUl0v9k4t8s+wM+3zUAsGo+AXuRLahdYwP2SycQWHTA4vcAAPK7b8HUKAgDgGiD4c93/+8//UegJQCAZkmScQAAXkQkLlTKsz/HCAAARKCBKrBBG/TBGCzABhzBBdzBC/xgNoRCJMTCQhBCCmSAHHJgKayCQiiGzbAdKmAv1EAdNMBRaIaTcA4uwlW4Dj1wD/phCJ7BKLyBCQRByAgTYSHaiAFiilgjjggXmYX4IcFIBBKLJCDJiBRRIkuRNUgxUopUIFVIHfI9cgI5h1xGupE7yAAygvyGvEcxlIGyUT3UDLVDuag3GoRGogvQZHQxmo8WoJvQcrQaPYw2oefQq2gP2o8+Q8cwwOgYBzPEbDAuxsNCsTgsCZNjy7EirAyrxhqwVqwDu4n1Y8+xdwQSgUXACTYEd0IgYR5BSFhMWE7YSKggHCQ0EdoJNwkDhFHCJyKTqEu0JroR+cQYYjIxh1hILCPWEo8TLxB7iEPENyQSiUMyJ7mQAkmxpFTSEtJG0m5SI+ksqZs0SBojk8naZGuyBzmULCAryIXkneTD5DPkG+Qh8lsKnWJAcaT4U+IoUspqShnlEOU05QZlmDJBVaOaUt2ooVQRNY9aQq2htlKvUYeoEzR1mjnNgxZJS6WtopXTGmgXaPdpr+h0uhHdlR5Ol9BX0svpR+iX6AP0dwwNhhWDx4hnKBmbGAcYZxl3GK+YTKYZ04sZx1QwNzHrmOeZD5lvVVgqtip8FZHKCpVKlSaVGyovVKmqpqreqgtV81XLVI+pXlN9rkZVM1PjqQnUlqtVqp1Q61MbU2epO6iHqmeob1Q/pH5Z/YkGWcNMw09DpFGgsV/jvMYgC2MZs3gsIWsNq4Z1gTXEJrHN2Xx2KruY/R27iz2qqaE5QzNKM1ezUvOUZj8H45hx+Jx0TgnnKKeX836K3hTvKeIpG6Y0TLkxZVxrqpaXllirSKtRq0frvTau7aedpr1Fu1n7gQ5Bx0onXCdHZ4/OBZ3nU9lT3acKpxZNPTr1ri6qa6UbobtEd79up+6Ynr5egJ5Mb6feeb3n+hx9L/1U/W36p/VHDFgGswwkBtsMzhg8xTVxbzwdL8fb8VFDXcNAQ6VhlWGX4YSRudE8o9VGjUYPjGnGXOMk423GbcajJgYmISZLTepN7ppSTbmmKaY7TDtMx83MzaLN1pk1mz0x1zLnm+eb15vft2BaeFostqi2uGVJsuRaplnutrxuhVo5WaVYVVpds0atna0l1rutu6cRp7lOk06rntZnw7Dxtsm2qbcZsOXYBtuutm22fWFnYhdnt8Wuw+6TvZN9un2N/T0HDYfZDqsdWh1+c7RyFDpWOt6azpzuP33F9JbpL2dYzxDP2DPjthPLKcRpnVOb00dnF2e5c4PziIuJS4LLLpc+Lpsbxt3IveRKdPVxXeF60vWdm7Obwu2o26/uNu5p7ofcn8w0nymeWTNz0MPIQ+BR5dE/C5+VMGvfrH5PQ0+BZ7XnIy9jL5FXrdewt6V3qvdh7xc+9j5yn+M+4zw33jLeWV/MN8C3yLfLT8Nvnl+F30N/I/9k/3r/0QCngCUBZwOJgUGBWwL7+Hp8Ib+OPzrbZfay2e1BjKC5QRVBj4KtguXBrSFoyOyQrSH355jOkc5pDoVQfujW0Adh5mGLw34MJ4WHhVeGP45wiFga0TGXNXfR3ENz30T6RJZE3ptnMU85ry1KNSo+qi5qPNo3ujS6P8YuZlnM1VidWElsSxw5LiquNm5svt/87fOH4p3iC+N7F5gvyF1weaHOwvSFpxapLhIsOpZATIhOOJTwQRAqqBaMJfITdyWOCnnCHcJnIi/RNtGI2ENcKh5O8kgqTXqS7JG8NXkkxTOlLOW5hCepkLxMDUzdmzqeFpp2IG0yPTq9MYOSkZBxQqohTZO2Z+pn5mZ2y6xlhbL+xW6Lty8elQfJa7OQrAVZLQq2QqboVFoo1yoHsmdlV2a/zYnKOZarnivN7cyzytuQN5zvn//tEsIS4ZK2pYZLVy0dWOa9rGo5sjxxedsK4xUFK4ZWBqw8uIq2Km3VT6vtV5eufr0mek1rgV7ByoLBtQFr6wtVCuWFfevc1+1dT1gvWd+1YfqGnRs+FYmKrhTbF5cVf9go3HjlG4dvyr+Z3JS0qavEuWTPZtJm6ebeLZ5bDpaql+aXDm4N2dq0Dd9WtO319kXbL5fNKNu7g7ZDuaO/PLi8ZafJzs07P1SkVPRU+lQ27tLdtWHX+G7R7ht7vPY07NXbW7z3/T7JvttVAVVN1WbVZftJ+7P3P66Jqun4lvttXa1ObXHtxwPSA/0HIw6217nU1R3SPVRSj9Yr60cOxx++/p3vdy0NNg1VjZzG4iNwRHnk6fcJ3/ceDTradox7rOEH0x92HWcdL2pCmvKaRptTmvtbYlu6T8w+0dbq3nr8R9sfD5w0PFl5SvNUyWna6YLTk2fyz4ydlZ19fi753GDborZ752PO32oPb++6EHTh0kX/i+c7vDvOXPK4dPKy2+UTV7hXmq86X23qdOo8/pPTT8e7nLuarrlca7nuer21e2b36RueN87d9L158Rb/1tWeOT3dvfN6b/fF9/XfFt1+cif9zsu72Xcn7q28T7xf9EDtQdlD3YfVP1v+3Njv3H9qwHeg89HcR/cGhYPP/pH1jw9DBY+Zj8uGDYbrnjg+OTniP3L96fynQ89kzyaeF/6i/suuFxYvfvjV69fO0ZjRoZfyl5O/bXyl/erA6xmv28bCxh6+yXgzMV70VvvtwXfcdx3vo98PT+R8IH8o/2j5sfVT0Kf7kxmTk/8EA5jz/GMzLdsAAAAgY0hSTQAAeiUAAICDAAD5/wAAgOkAAHUwAADqYAAAOpgAABdvkl/FRgAABCFJREFUeNrsm09oFFcYwH9JBjY0YGSFHSJEUkjooT0UAwo9BFo8CBEqNOQQkcVDIQWhhxYPW2LxkDlVUCwUejFz6KEFIcccRMFApQElHoKKK4pKlg00YGDFhQntYb6VIXnzdt8m48y074Nld9/73sz7zfv+vJk3r6e0ME8X4gCjwDRwAWgA28C4/N5StBkBvgIuAoGUHRfdDYX+kOjPAf1SNiG6tZZSvVwx7ng30gc8jPwfkO914LAC2BGAn3aUPwHGFMAOUAKu7ShfBT6NAptKb5ftBjV1JxRlB4A/Y/QnFWUFgVPJNHuQuBEuAR+IKTXkigYdHrN/Hy5en0b/gKrQ9b1R4SkAm0CjXq5sththRw44BzwTs30h5jhgYO775TodDZLre0XgL+nvqvT5vOt7BR3wkJjLa+D8Dr0XwEdkUFzfG5a+FXdUXQIuur53TgVckCj6m+bY42RTRjTxoQJUXN9zosAF4GNNo5a8zChwtU39KLDo+t5MFPhem0aXJXhlUbaAT9roTAo4DvB7G+UJYNmgA01FmS7Cqy7ktkb/dfRPvVxpAGtAj+t7nwO3Ytpdcn3vdq+Ysw52U1H+VtOmFgPsGbhKAHwfo/9Uc+5N4EdN/Z2e0sL8PzGVU8ANTWoYkZmSKg83Y6aK6zF5WDUVLQJ/K8oPRQdBNbV0fe9X4GuTicfVNn4dyHRwAjgpgIH4+rbG1z4T/e1IbGhqTH0cOBXJ7Tr9qCybAleB5x0Ei2UD/24Ad+XTaSy4Lx9TWTOdSzfJt7wyBQ5yDvx2v++WcisW+L8u3dy2fSk5ciilPrdS2oqkzq2kgUeAK1m5O3R97029XAmSMOlh4FiGYAHqrZuCJICbpubznqSRFPAG8Aj4OUOwYxg+wezGh/8Alggf9KUlTbn4Gyb+2y3wMjkWm4c7kKK060u571uR29JEgSvAdxkZsA9d33uVVB4ekEA1myELfUbMSsR+ABcl0Q9kzC1LSQFvED5/upsx4PWkfLgpnxuED+2HU4QMZC5wE3iTdNC6nKXhNV0Qtw8A7MRjt8xIxC4a+v8DwlWGtbwBTwp0NzKVNrCJSQ8RrkPN7OF8c3nzYScFi0oNuCZ+eGYP55vKY9CqAl8YBq0AeIx66TXzwCs2D1tgC2yBLbAFtsAW2AJbYAtsgS2wBbbAFtgCW2ALbIEtcNLATs65Bk2BCzkHLpoCHwOO5hj4hCnwWdJ9h2OvEvtKsUP4cshJRd0i8A3h/qWlPFC6vneUcDl3Vgf8IAYY4BfguvhEE/2ew7QgWz/7xQ3j3hKsAad6SgvzhSyCJCBevVz5oZdw08SR/wHw7ZZJBzLcY6h3i+ZdAuCguOS7CUYgwWlMItws4XadvMtpoCabqnfNqALC1f2qpKTnwLc5Ba0SvhN6MwoL8O8AwUvuYBGaCTgAAAAASUVORK5CYII=" alt="FAQ icon" />
    <p>What is ...?</p>
  </label>
  
  <section id="answer1">
    <p>
      The answer is 42.
    </p>
  </section>
  
  <input id="question2" type="checkbox" name="toggle" class="question" />
  <label for="question2">
    <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADwAAABMCAYAAAAx3tSzAAAACXBIWXMAAC4jAAAuIwF4pT92AAAKT2lDQ1BQaG90b3Nob3AgSUNDIHByb2ZpbGUAAHjanVNnVFPpFj333vRCS4iAlEtvUhUIIFJCi4AUkSYqIQkQSoghodkVUcERRUUEG8igiAOOjoCMFVEsDIoK2AfkIaKOg6OIisr74Xuja9a89+bN/rXXPues852zzwfACAyWSDNRNYAMqUIeEeCDx8TG4eQuQIEKJHAAEAizZCFz/SMBAPh+PDwrIsAHvgABeNMLCADATZvAMByH/w/qQplcAYCEAcB0kThLCIAUAEB6jkKmAEBGAYCdmCZTAKAEAGDLY2LjAFAtAGAnf+bTAICd+Jl7AQBblCEVAaCRACATZYhEAGg7AKzPVopFAFgwABRmS8Q5ANgtADBJV2ZIALC3AMDOEAuyAAgMADBRiIUpAAR7AGDIIyN4AISZABRG8lc88SuuEOcqAAB4mbI8uSQ5RYFbCC1xB1dXLh4ozkkXKxQ2YQJhmkAuwnmZGTKBNA/g88wAAKCRFRHgg/P9eM4Ors7ONo62Dl8t6r8G/yJiYuP+5c+rcEAAAOF0ftH+LC+zGoA7BoBt/qIl7gRoXgugdfeLZrIPQLUAoOnaV/Nw+H48PEWhkLnZ2eXk5NhKxEJbYcpXff5nwl/AV/1s+X48/Pf14L7iJIEyXYFHBPjgwsz0TKUcz5IJhGLc5o9H/LcL//wd0yLESWK5WCoU41EScY5EmozzMqUiiUKSKcUl0v9k4t8s+wM+3zUAsGo+AXuRLahdYwP2SycQWHTA4vcAAPK7b8HUKAgDgGiD4c93/+8//UegJQCAZkmScQAAXkQkLlTKsz/HCAAARKCBKrBBG/TBGCzABhzBBdzBC/xgNoRCJMTCQhBCCmSAHHJgKayCQiiGzbAdKmAv1EAdNMBRaIaTcA4uwlW4Dj1wD/phCJ7BKLyBCQRByAgTYSHaiAFiilgjjggXmYX4IcFIBBKLJCDJiBRRIkuRNUgxUopUIFVIHfI9cgI5h1xGupE7yAAygvyGvEcxlIGyUT3UDLVDuag3GoRGogvQZHQxmo8WoJvQcrQaPYw2oefQq2gP2o8+Q8cwwOgYBzPEbDAuxsNCsTgsCZNjy7EirAyrxhqwVqwDu4n1Y8+xdwQSgUXACTYEd0IgYR5BSFhMWE7YSKggHCQ0EdoJNwkDhFHCJyKTqEu0JroR+cQYYjIxh1hILCPWEo8TLxB7iEPENyQSiUMyJ7mQAkmxpFTSEtJG0m5SI+ksqZs0SBojk8naZGuyBzmULCAryIXkneTD5DPkG+Qh8lsKnWJAcaT4U+IoUspqShnlEOU05QZlmDJBVaOaUt2ooVQRNY9aQq2htlKvUYeoEzR1mjnNgxZJS6WtopXTGmgXaPdpr+h0uhHdlR5Ol9BX0svpR+iX6AP0dwwNhhWDx4hnKBmbGAcYZxl3GK+YTKYZ04sZx1QwNzHrmOeZD5lvVVgqtip8FZHKCpVKlSaVGyovVKmqpqreqgtV81XLVI+pXlN9rkZVM1PjqQnUlqtVqp1Q61MbU2epO6iHqmeob1Q/pH5Z/YkGWcNMw09DpFGgsV/jvMYgC2MZs3gsIWsNq4Z1gTXEJrHN2Xx2KruY/R27iz2qqaE5QzNKM1ezUvOUZj8H45hx+Jx0TgnnKKeX836K3hTvKeIpG6Y0TLkxZVxrqpaXllirSKtRq0frvTau7aedpr1Fu1n7gQ5Bx0onXCdHZ4/OBZ3nU9lT3acKpxZNPTr1ri6qa6UbobtEd79up+6Ynr5egJ5Mb6feeb3n+hx9L/1U/W36p/VHDFgGswwkBtsMzhg8xTVxbzwdL8fb8VFDXcNAQ6VhlWGX4YSRudE8o9VGjUYPjGnGXOMk423GbcajJgYmISZLTepN7ppSTbmmKaY7TDtMx83MzaLN1pk1mz0x1zLnm+eb15vft2BaeFostqi2uGVJsuRaplnutrxuhVo5WaVYVVpds0atna0l1rutu6cRp7lOk06rntZnw7Dxtsm2qbcZsOXYBtuutm22fWFnYhdnt8Wuw+6TvZN9un2N/T0HDYfZDqsdWh1+c7RyFDpWOt6azpzuP33F9JbpL2dYzxDP2DPjthPLKcRpnVOb00dnF2e5c4PziIuJS4LLLpc+Lpsbxt3IveRKdPVxXeF60vWdm7Obwu2o26/uNu5p7ofcn8w0nymeWTNz0MPIQ+BR5dE/C5+VMGvfrH5PQ0+BZ7XnIy9jL5FXrdewt6V3qvdh7xc+9j5yn+M+4zw33jLeWV/MN8C3yLfLT8Nvnl+F30N/I/9k/3r/0QCngCUBZwOJgUGBWwL7+Hp8Ib+OPzrbZfay2e1BjKC5QRVBj4KtguXBrSFoyOyQrSH355jOkc5pDoVQfujW0Adh5mGLw34MJ4WHhVeGP45wiFga0TGXNXfR3ENz30T6RJZE3ptnMU85ry1KNSo+qi5qPNo3ujS6P8YuZlnM1VidWElsSxw5LiquNm5svt/87fOH4p3iC+N7F5gvyF1weaHOwvSFpxapLhIsOpZATIhOOJTwQRAqqBaMJfITdyWOCnnCHcJnIi/RNtGI2ENcKh5O8kgqTXqS7JG8NXkkxTOlLOW5hCepkLxMDUzdmzqeFpp2IG0yPTq9MYOSkZBxQqohTZO2Z+pn5mZ2y6xlhbL+xW6Lty8elQfJa7OQrAVZLQq2QqboVFoo1yoHsmdlV2a/zYnKOZarnivN7cyzytuQN5zvn//tEsIS4ZK2pYZLVy0dWOa9rGo5sjxxedsK4xUFK4ZWBqw8uIq2Km3VT6vtV5eufr0mek1rgV7ByoLBtQFr6wtVCuWFfevc1+1dT1gvWd+1YfqGnRs+FYmKrhTbF5cVf9go3HjlG4dvyr+Z3JS0qavEuWTPZtJm6ebeLZ5bDpaql+aXDm4N2dq0Dd9WtO319kXbL5fNKNu7g7ZDuaO/PLi8ZafJzs07P1SkVPRU+lQ27tLdtWHX+G7R7ht7vPY07NXbW7z3/T7JvttVAVVN1WbVZftJ+7P3P66Jqun4lvttXa1ObXHtxwPSA/0HIw6217nU1R3SPVRSj9Yr60cOxx++/p3vdy0NNg1VjZzG4iNwRHnk6fcJ3/ceDTradox7rOEH0x92HWcdL2pCmvKaRptTmvtbYlu6T8w+0dbq3nr8R9sfD5w0PFl5SvNUyWna6YLTk2fyz4ydlZ19fi753GDborZ752PO32oPb++6EHTh0kX/i+c7vDvOXPK4dPKy2+UTV7hXmq86X23qdOo8/pPTT8e7nLuarrlca7nuer21e2b36RueN87d9L158Rb/1tWeOT3dvfN6b/fF9/XfFt1+cif9zsu72Xcn7q28T7xf9EDtQdlD3YfVP1v+3Njv3H9qwHeg89HcR/cGhYPP/pH1jw9DBY+Zj8uGDYbrnjg+OTniP3L96fynQ89kzyaeF/6i/suuFxYvfvjV69fO0ZjRoZfyl5O/bXyl/erA6xmv28bCxh6+yXgzMV70VvvtwXfcdx3vo98PT+R8IH8o/2j5sfVT0Kf7kxmTk/8EA5jz/GMzLdsAAAAgY0hSTQAAeiUAAICDAAD5/wAAgOkAAHUwAADqYAAAOpgAABdvkl/FRgAABCFJREFUeNrsm09oFFcYwH9JBjY0YGSFHSJEUkjooT0UAwo9BFo8CBEqNOQQkcVDIQWhhxYPW2LxkDlVUCwUejFz6KEFIcccRMFApQElHoKKK4pKlg00YGDFhQntYb6VIXnzdt8m48y074Nld9/73sz7zfv+vJk3r6e0ME8X4gCjwDRwAWgA28C4/N5StBkBvgIuAoGUHRfdDYX+kOjPAf1SNiG6tZZSvVwx7ng30gc8jPwfkO914LAC2BGAn3aUPwHGFMAOUAKu7ShfBT6NAptKb5ftBjV1JxRlB4A/Y/QnFWUFgVPJNHuQuBEuAR+IKTXkigYdHrN/Hy5en0b/gKrQ9b1R4SkAm0CjXq5sththRw44BzwTs30h5jhgYO775TodDZLre0XgL+nvqvT5vOt7BR3wkJjLa+D8Dr0XwEdkUFzfG5a+FXdUXQIuur53TgVckCj6m+bY42RTRjTxoQJUXN9zosAF4GNNo5a8zChwtU39KLDo+t5MFPhem0aXJXhlUbaAT9roTAo4DvB7G+UJYNmgA01FmS7Cqy7ktkb/dfRPvVxpAGtAj+t7nwO3Ytpdcn3vdq+Ysw52U1H+VtOmFgPsGbhKAHwfo/9Uc+5N4EdN/Z2e0sL8PzGVU8ANTWoYkZmSKg83Y6aK6zF5WDUVLQJ/K8oPRQdBNbV0fe9X4GuTicfVNn4dyHRwAjgpgIH4+rbG1z4T/e1IbGhqTH0cOBXJ7Tr9qCybAleB5x0Ei2UD/24Ad+XTaSy4Lx9TWTOdSzfJt7wyBQ5yDvx2v++WcisW+L8u3dy2fSk5ciilPrdS2oqkzq2kgUeAK1m5O3R97029XAmSMOlh4FiGYAHqrZuCJICbpubznqSRFPAG8Aj4OUOwYxg+wezGh/8Alggf9KUlTbn4Gyb+2y3wMjkWm4c7kKK060u571uR29JEgSvAdxkZsA9d33uVVB4ekEA1myELfUbMSsR+ABcl0Q9kzC1LSQFvED5/upsx4PWkfLgpnxuED+2HU4QMZC5wE3iTdNC6nKXhNV0Qtw8A7MRjt8xIxC4a+v8DwlWGtbwBTwp0NzKVNrCJSQ8RrkPN7OF8c3nzYScFi0oNuCZ+eGYP55vKY9CqAl8YBq0AeIx66TXzwCs2D1tgC2yBLbAFtsAW2AJbYAtsgS2wBbbAFtgCW2ALbIEtcNLATs65Bk2BCzkHLpoCHwOO5hj4hCnwWdJ9h2OvEvtKsUP4cshJRd0i8A3h/qWlPFC6vneUcDl3Vgf8IAYY4BfguvhEE/2ew7QgWz/7xQ3j3hKsAad6SgvzhSyCJCBevVz5oZdw08SR/wHw7ZZJBzLcY6h3i+ZdAuCguOS7CUYgwWlMItws4XadvMtpoCabqnfNqALC1f2qpKTnwLc5Ba0SvhN6MwoL8O8AwUvuYBGaCTgAAAAASUVORK5CYII=" alt="FAQ icon" />
    <p>How do I ...?</p>
  </label>
  
  <section id="answer2">
    <p>
      You don't. Simple.
    </p>
  </section>
  
  <input id="question3" type="checkbox" name="toggle" class="question" />
  <label for="question3">
    <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADwAAABMCAYAAAAx3tSzAAAACXBIWXMAAC4jAAAuIwF4pT92AAAKT2lDQ1BQaG90b3Nob3AgSUNDIHByb2ZpbGUAAHjanVNnVFPpFj333vRCS4iAlEtvUhUIIFJCi4AUkSYqIQkQSoghodkVUcERRUUEG8igiAOOjoCMFVEsDIoK2AfkIaKOg6OIisr74Xuja9a89+bN/rXXPues852zzwfACAyWSDNRNYAMqUIeEeCDx8TG4eQuQIEKJHAAEAizZCFz/SMBAPh+PDwrIsAHvgABeNMLCADATZvAMByH/w/qQplcAYCEAcB0kThLCIAUAEB6jkKmAEBGAYCdmCZTAKAEAGDLY2LjAFAtAGAnf+bTAICd+Jl7AQBblCEVAaCRACATZYhEAGg7AKzPVopFAFgwABRmS8Q5ANgtADBJV2ZIALC3AMDOEAuyAAgMADBRiIUpAAR7AGDIIyN4AISZABRG8lc88SuuEOcqAAB4mbI8uSQ5RYFbCC1xB1dXLh4ozkkXKxQ2YQJhmkAuwnmZGTKBNA/g88wAAKCRFRHgg/P9eM4Ors7ONo62Dl8t6r8G/yJiYuP+5c+rcEAAAOF0ftH+LC+zGoA7BoBt/qIl7gRoXgugdfeLZrIPQLUAoOnaV/Nw+H48PEWhkLnZ2eXk5NhKxEJbYcpXff5nwl/AV/1s+X48/Pf14L7iJIEyXYFHBPjgwsz0TKUcz5IJhGLc5o9H/LcL//wd0yLESWK5WCoU41EScY5EmozzMqUiiUKSKcUl0v9k4t8s+wM+3zUAsGo+AXuRLahdYwP2SycQWHTA4vcAAPK7b8HUKAgDgGiD4c93/+8//UegJQCAZkmScQAAXkQkLlTKsz/HCAAARKCBKrBBG/TBGCzABhzBBdzBC/xgNoRCJMTCQhBCCmSAHHJgKayCQiiGzbAdKmAv1EAdNMBRaIaTcA4uwlW4Dj1wD/phCJ7BKLyBCQRByAgTYSHaiAFiilgjjggXmYX4IcFIBBKLJCDJiBRRIkuRNUgxUopUIFVIHfI9cgI5h1xGupE7yAAygvyGvEcxlIGyUT3UDLVDuag3GoRGogvQZHQxmo8WoJvQcrQaPYw2oefQq2gP2o8+Q8cwwOgYBzPEbDAuxsNCsTgsCZNjy7EirAyrxhqwVqwDu4n1Y8+xdwQSgUXACTYEd0IgYR5BSFhMWE7YSKggHCQ0EdoJNwkDhFHCJyKTqEu0JroR+cQYYjIxh1hILCPWEo8TLxB7iEPENyQSiUMyJ7mQAkmxpFTSEtJG0m5SI+ksqZs0SBojk8naZGuyBzmULCAryIXkneTD5DPkG+Qh8lsKnWJAcaT4U+IoUspqShnlEOU05QZlmDJBVaOaUt2ooVQRNY9aQq2htlKvUYeoEzR1mjnNgxZJS6WtopXTGmgXaPdpr+h0uhHdlR5Ol9BX0svpR+iX6AP0dwwNhhWDx4hnKBmbGAcYZxl3GK+YTKYZ04sZx1QwNzHrmOeZD5lvVVgqtip8FZHKCpVKlSaVGyovVKmqpqreqgtV81XLVI+pXlN9rkZVM1PjqQnUlqtVqp1Q61MbU2epO6iHqmeob1Q/pH5Z/YkGWcNMw09DpFGgsV/jvMYgC2MZs3gsIWsNq4Z1gTXEJrHN2Xx2KruY/R27iz2qqaE5QzNKM1ezUvOUZj8H45hx+Jx0TgnnKKeX836K3hTvKeIpG6Y0TLkxZVxrqpaXllirSKtRq0frvTau7aedpr1Fu1n7gQ5Bx0onXCdHZ4/OBZ3nU9lT3acKpxZNPTr1ri6qa6UbobtEd79up+6Ynr5egJ5Mb6feeb3n+hx9L/1U/W36p/VHDFgGswwkBtsMzhg8xTVxbzwdL8fb8VFDXcNAQ6VhlWGX4YSRudE8o9VGjUYPjGnGXOMk423GbcajJgYmISZLTepN7ppSTbmmKaY7TDtMx83MzaLN1pk1mz0x1zLnm+eb15vft2BaeFostqi2uGVJsuRaplnutrxuhVo5WaVYVVpds0atna0l1rutu6cRp7lOk06rntZnw7Dxtsm2qbcZsOXYBtuutm22fWFnYhdnt8Wuw+6TvZN9un2N/T0HDYfZDqsdWh1+c7RyFDpWOt6azpzuP33F9JbpL2dYzxDP2DPjthPLKcRpnVOb00dnF2e5c4PziIuJS4LLLpc+Lpsbxt3IveRKdPVxXeF60vWdm7Obwu2o26/uNu5p7ofcn8w0nymeWTNz0MPIQ+BR5dE/C5+VMGvfrH5PQ0+BZ7XnIy9jL5FXrdewt6V3qvdh7xc+9j5yn+M+4zw33jLeWV/MN8C3yLfLT8Nvnl+F30N/I/9k/3r/0QCngCUBZwOJgUGBWwL7+Hp8Ib+OPzrbZfay2e1BjKC5QRVBj4KtguXBrSFoyOyQrSH355jOkc5pDoVQfujW0Adh5mGLw34MJ4WHhVeGP45wiFga0TGXNXfR3ENz30T6RJZE3ptnMU85ry1KNSo+qi5qPNo3ujS6P8YuZlnM1VidWElsSxw5LiquNm5svt/87fOH4p3iC+N7F5gvyF1weaHOwvSFpxapLhIsOpZATIhOOJTwQRAqqBaMJfITdyWOCnnCHcJnIi/RNtGI2ENcKh5O8kgqTXqS7JG8NXkkxTOlLOW5hCepkLxMDUzdmzqeFpp2IG0yPTq9MYOSkZBxQqohTZO2Z+pn5mZ2y6xlhbL+xW6Lty8elQfJa7OQrAVZLQq2QqboVFoo1yoHsmdlV2a/zYnKOZarnivN7cyzytuQN5zvn//tEsIS4ZK2pYZLVy0dWOa9rGo5sjxxedsK4xUFK4ZWBqw8uIq2Km3VT6vtV5eufr0mek1rgV7ByoLBtQFr6wtVCuWFfevc1+1dT1gvWd+1YfqGnRs+FYmKrhTbF5cVf9go3HjlG4dvyr+Z3JS0qavEuWTPZtJm6ebeLZ5bDpaql+aXDm4N2dq0Dd9WtO319kXbL5fNKNu7g7ZDuaO/PLi8ZafJzs07P1SkVPRU+lQ27tLdtWHX+G7R7ht7vPY07NXbW7z3/T7JvttVAVVN1WbVZftJ+7P3P66Jqun4lvttXa1ObXHtxwPSA/0HIw6217nU1R3SPVRSj9Yr60cOxx++/p3vdy0NNg1VjZzG4iNwRHnk6fcJ3/ceDTradox7rOEH0x92HWcdL2pCmvKaRptTmvtbYlu6T8w+0dbq3nr8R9sfD5w0PFl5SvNUyWna6YLTk2fyz4ydlZ19fi753GDborZ752PO32oPb++6EHTh0kX/i+c7vDvOXPK4dPKy2+UTV7hXmq86X23qdOo8/pPTT8e7nLuarrlca7nuer21e2b36RueN87d9L158Rb/1tWeOT3dvfN6b/fF9/XfFt1+cif9zsu72Xcn7q28T7xf9EDtQdlD3YfVP1v+3Njv3H9qwHeg89HcR/cGhYPP/pH1jw9DBY+Zj8uGDYbrnjg+OTniP3L96fynQ89kzyaeF/6i/suuFxYvfvjV69fO0ZjRoZfyl5O/bXyl/erA6xmv28bCxh6+yXgzMV70VvvtwXfcdx3vo98PT+R8IH8o/2j5sfVT0Kf7kxmTk/8EA5jz/GMzLdsAAAAgY0hSTQAAeiUAAICDAAD5/wAAgOkAAHUwAADqYAAAOpgAABdvkl/FRgAABCFJREFUeNrsm09oFFcYwH9JBjY0YGSFHSJEUkjooT0UAwo9BFo8CBEqNOQQkcVDIQWhhxYPW2LxkDlVUCwUejFz6KEFIcccRMFApQElHoKKK4pKlg00YGDFhQntYb6VIXnzdt8m48y074Nld9/73sz7zfv+vJk3r6e0ME8X4gCjwDRwAWgA28C4/N5StBkBvgIuAoGUHRfdDYX+kOjPAf1SNiG6tZZSvVwx7ng30gc8jPwfkO914LAC2BGAn3aUPwHGFMAOUAKu7ShfBT6NAptKb5ftBjV1JxRlB4A/Y/QnFWUFgVPJNHuQuBEuAR+IKTXkigYdHrN/Hy5en0b/gKrQ9b1R4SkAm0CjXq5sththRw44BzwTs30h5jhgYO775TodDZLre0XgL+nvqvT5vOt7BR3wkJjLa+D8Dr0XwEdkUFzfG5a+FXdUXQIuur53TgVckCj6m+bY42RTRjTxoQJUXN9zosAF4GNNo5a8zChwtU39KLDo+t5MFPhem0aXJXhlUbaAT9roTAo4DvB7G+UJYNmgA01FmS7Cqy7ktkb/dfRPvVxpAGtAj+t7nwO3Ytpdcn3vdq+Ysw52U1H+VtOmFgPsGbhKAHwfo/9Uc+5N4EdN/Z2e0sL8PzGVU8ANTWoYkZmSKg83Y6aK6zF5WDUVLQJ/K8oPRQdBNbV0fe9X4GuTicfVNn4dyHRwAjgpgIH4+rbG1z4T/e1IbGhqTH0cOBXJ7Tr9qCybAleB5x0Ei2UD/24Ad+XTaSy4Lx9TWTOdSzfJt7wyBQ5yDvx2v++WcisW+L8u3dy2fSk5ciilPrdS2oqkzq2kgUeAK1m5O3R97029XAmSMOlh4FiGYAHqrZuCJICbpubznqSRFPAG8Aj4OUOwYxg+wezGh/8Alggf9KUlTbn4Gyb+2y3wMjkWm4c7kKK060u571uR29JEgSvAdxkZsA9d33uVVB4ekEA1myELfUbMSsR+ABcl0Q9kzC1LSQFvED5/upsx4PWkfLgpnxuED+2HU4QMZC5wE3iTdNC6nKXhNV0Qtw8A7MRjt8xIxC4a+v8DwlWGtbwBTwp0NzKVNrCJSQ8RrkPN7OF8c3nzYScFi0oNuCZ+eGYP55vKY9CqAl8YBq0AeIx66TXzwCs2D1tgC2yBLbAFtsAW2AJbYAtsgS2wBbbAFtgCW2ALbIEtcNLATs65Bk2BCzkHLpoCHwOO5hj4hCnwWdJ9h2OvEvtKsUP4cshJRd0i8A3h/qWlPFC6vneUcDl3Vgf8IAYY4BfguvhEE/2ew7QgWz/7xQ3j3hKsAad6SgvzhSyCJCBevVz5oZdw08SR/wHw7ZZJBzLcY6h3i+ZdAuCguOS7CUYgwWlMItws4XadvMtpoCabqnfNqALC1f2qpKTnwLc5Ba0SvhN6MwoL8O8AwUvuYBGaCTgAAAAASUVORK5CYII=" alt="FAQ icon" />
    <p>Does this question<br />break onto a new line?</p>
  </label>
  
  <section id="answer3">
    <p>
      Yes, and it looks good. Pretty awesome, eh?
    </p>
  </section>

  <input id="question4" type="checkbox" name="toggle" class="question" />
  <label for="question4">
    <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADwAAABMCAYAAAAx3tSzAAAACXBIWXMAAC4jAAAuIwF4pT92AAAKT2lDQ1BQaG90b3Nob3AgSUNDIHByb2ZpbGUAAHjanVNnVFPpFj333vRCS4iAlEtvUhUIIFJCi4AUkSYqIQkQSoghodkVUcERRUUEG8igiAOOjoCMFVEsDIoK2AfkIaKOg6OIisr74Xuja9a89+bN/rXXPues852zzwfACAyWSDNRNYAMqUIeEeCDx8TG4eQuQIEKJHAAEAizZCFz/SMBAPh+PDwrIsAHvgABeNMLCADATZvAMByH/w/qQplcAYCEAcB0kThLCIAUAEB6jkKmAEBGAYCdmCZTAKAEAGDLY2LjAFAtAGAnf+bTAICd+Jl7AQBblCEVAaCRACATZYhEAGg7AKzPVopFAFgwABRmS8Q5ANgtADBJV2ZIALC3AMDOEAuyAAgMADBRiIUpAAR7AGDIIyN4AISZABRG8lc88SuuEOcqAAB4mbI8uSQ5RYFbCC1xB1dXLh4ozkkXKxQ2YQJhmkAuwnmZGTKBNA/g88wAAKCRFRHgg/P9eM4Ors7ONo62Dl8t6r8G/yJiYuP+5c+rcEAAAOF0ftH+LC+zGoA7BoBt/qIl7gRoXgugdfeLZrIPQLUAoOnaV/Nw+H48PEWhkLnZ2eXk5NhKxEJbYcpXff5nwl/AV/1s+X48/Pf14L7iJIEyXYFHBPjgwsz0TKUcz5IJhGLc5o9H/LcL//wd0yLESWK5WCoU41EScY5EmozzMqUiiUKSKcUl0v9k4t8s+wM+3zUAsGo+AXuRLahdYwP2SycQWHTA4vcAAPK7b8HUKAgDgGiD4c93/+8//UegJQCAZkmScQAAXkQkLlTKsz/HCAAARKCBKrBBG/TBGCzABhzBBdzBC/xgNoRCJMTCQhBCCmSAHHJgKayCQiiGzbAdKmAv1EAdNMBRaIaTcA4uwlW4Dj1wD/phCJ7BKLyBCQRByAgTYSHaiAFiilgjjggXmYX4IcFIBBKLJCDJiBRRIkuRNUgxUopUIFVIHfI9cgI5h1xGupE7yAAygvyGvEcxlIGyUT3UDLVDuag3GoRGogvQZHQxmo8WoJvQcrQaPYw2oefQq2gP2o8+Q8cwwOgYBzPEbDAuxsNCsTgsCZNjy7EirAyrxhqwVqwDu4n1Y8+xdwQSgUXACTYEd0IgYR5BSFhMWE7YSKggHCQ0EdoJNwkDhFHCJyKTqEu0JroR+cQYYjIxh1hILCPWEo8TLxB7iEPENyQSiUMyJ7mQAkmxpFTSEtJG0m5SI+ksqZs0SBojk8naZGuyBzmULCAryIXkneTD5DPkG+Qh8lsKnWJAcaT4U+IoUspqShnlEOU05QZlmDJBVaOaUt2ooVQRNY9aQq2htlKvUYeoEzR1mjnNgxZJS6WtopXTGmgXaPdpr+h0uhHdlR5Ol9BX0svpR+iX6AP0dwwNhhWDx4hnKBmbGAcYZxl3GK+YTKYZ04sZx1QwNzHrmOeZD5lvVVgqtip8FZHKCpVKlSaVGyovVKmqpqreqgtV81XLVI+pXlN9rkZVM1PjqQnUlqtVqp1Q61MbU2epO6iHqmeob1Q/pH5Z/YkGWcNMw09DpFGgsV/jvMYgC2MZs3gsIWsNq4Z1gTXEJrHN2Xx2KruY/R27iz2qqaE5QzNKM1ezUvOUZj8H45hx+Jx0TgnnKKeX836K3hTvKeIpG6Y0TLkxZVxrqpaXllirSKtRq0frvTau7aedpr1Fu1n7gQ5Bx0onXCdHZ4/OBZ3nU9lT3acKpxZNPTr1ri6qa6UbobtEd79up+6Ynr5egJ5Mb6feeb3n+hx9L/1U/W36p/VHDFgGswwkBtsMzhg8xTVxbzwdL8fb8VFDXcNAQ6VhlWGX4YSRudE8o9VGjUYPjGnGXOMk423GbcajJgYmISZLTepN7ppSTbmmKaY7TDtMx83MzaLN1pk1mz0x1zLnm+eb15vft2BaeFostqi2uGVJsuRaplnutrxuhVo5WaVYVVpds0atna0l1rutu6cRp7lOk06rntZnw7Dxtsm2qbcZsOXYBtuutm22fWFnYhdnt8Wuw+6TvZN9un2N/T0HDYfZDqsdWh1+c7RyFDpWOt6azpzuP33F9JbpL2dYzxDP2DPjthPLKcRpnVOb00dnF2e5c4PziIuJS4LLLpc+Lpsbxt3IveRKdPVxXeF60vWdm7Obwu2o26/uNu5p7ofcn8w0nymeWTNz0MPIQ+BR5dE/C5+VMGvfrH5PQ0+BZ7XnIy9jL5FXrdewt6V3qvdh7xc+9j5yn+M+4zw33jLeWV/MN8C3yLfLT8Nvnl+F30N/I/9k/3r/0QCngCUBZwOJgUGBWwL7+Hp8Ib+OPzrbZfay2e1BjKC5QRVBj4KtguXBrSFoyOyQrSH355jOkc5pDoVQfujW0Adh5mGLw34MJ4WHhVeGP45wiFga0TGXNXfR3ENz30T6RJZE3ptnMU85ry1KNSo+qi5qPNo3ujS6P8YuZlnM1VidWElsSxw5LiquNm5svt/87fOH4p3iC+N7F5gvyF1weaHOwvSFpxapLhIsOpZATIhOOJTwQRAqqBaMJfITdyWOCnnCHcJnIi/RNtGI2ENcKh5O8kgqTXqS7JG8NXkkxTOlLOW5hCepkLxMDUzdmzqeFpp2IG0yPTq9MYOSkZBxQqohTZO2Z+pn5mZ2y6xlhbL+xW6Lty8elQfJa7OQrAVZLQq2QqboVFoo1yoHsmdlV2a/zYnKOZarnivN7cyzytuQN5zvn//tEsIS4ZK2pYZLVy0dWOa9rGo5sjxxedsK4xUFK4ZWBqw8uIq2Km3VT6vtV5eufr0mek1rgV7ByoLBtQFr6wtVCuWFfevc1+1dT1gvWd+1YfqGnRs+FYmKrhTbF5cVf9go3HjlG4dvyr+Z3JS0qavEuWTPZtJm6ebeLZ5bDpaql+aXDm4N2dq0Dd9WtO319kXbL5fNKNu7g7ZDuaO/PLi8ZafJzs07P1SkVPRU+lQ27tLdtWHX+G7R7ht7vPY07NXbW7z3/T7JvttVAVVN1WbVZftJ+7P3P66Jqun4lvttXa1ObXHtxwPSA/0HIw6217nU1R3SPVRSj9Yr60cOxx++/p3vdy0NNg1VjZzG4iNwRHnk6fcJ3/ceDTradox7rOEH0x92HWcdL2pCmvKaRptTmvtbYlu6T8w+0dbq3nr8R9sfD5w0PFl5SvNUyWna6YLTk2fyz4ydlZ19fi753GDborZ752PO32oPb++6EHTh0kX/i+c7vDvOXPK4dPKy2+UTV7hXmq86X23qdOo8/pPTT8e7nLuarrlca7nuer21e2b36RueN87d9L158Rb/1tWeOT3dvfN6b/fF9/XfFt1+cif9zsu72Xcn7q28T7xf9EDtQdlD3YfVP1v+3Njv3H9qwHeg89HcR/cGhYPP/pH1jw9DBY+Zj8uGDYbrnjg+OTniP3L96fynQ89kzyaeF/6i/suuFxYvfvjV69fO0ZjRoZfyl5O/bXyl/erA6xmv28bCxh6+yXgzMV70VvvtwXfcdx3vo98PT+R8IH8o/2j5sfVT0Kf7kxmTk/8EA5jz/GMzLdsAAAAgY0hSTQAAeiUAAICDAAD5/wAAgOkAAHUwAADqYAAAOpgAABdvkl/FRgAABCFJREFUeNrsm09oFFcYwH9JBjY0YGSFHSJEUkjooT0UAwo9BFo8CBEqNOQQkcVDIQWhhxYPW2LxkDlVUCwUejFz6KEFIcccRMFApQElHoKKK4pKlg00YGDFhQntYb6VIXnzdt8m48y074Nld9/73sz7zfv+vJk3r6e0ME8X4gCjwDRwAWgA28C4/N5StBkBvgIuAoGUHRfdDYX+kOjPAf1SNiG6tZZSvVwx7ng30gc8jPwfkO914LAC2BGAn3aUPwHGFMAOUAKu7ShfBT6NAptKb5ftBjV1JxRlB4A/Y/QnFWUFgVPJNHuQuBEuAR+IKTXkigYdHrN/Hy5en0b/gKrQ9b1R4SkAm0CjXq5sththRw44BzwTs30h5jhgYO775TodDZLre0XgL+nvqvT5vOt7BR3wkJjLa+D8Dr0XwEdkUFzfG5a+FXdUXQIuur53TgVckCj6m+bY42RTRjTxoQJUXN9zosAF4GNNo5a8zChwtU39KLDo+t5MFPhem0aXJXhlUbaAT9roTAo4DvB7G+UJYNmgA01FmS7Cqy7ktkb/dfRPvVxpAGtAj+t7nwO3Ytpdcn3vdq+Ysw52U1H+VtOmFgPsGbhKAHwfo/9Uc+5N4EdN/Z2e0sL8PzGVU8ANTWoYkZmSKg83Y6aK6zF5WDUVLQJ/K8oPRQdBNbV0fe9X4GuTicfVNn4dyHRwAjgpgIH4+rbG1z4T/e1IbGhqTH0cOBXJ7Tr9qCybAleB5x0Ei2UD/24Ad+XTaSy4Lx9TWTOdSzfJt7wyBQ5yDvx2v++WcisW+L8u3dy2fSk5ciilPrdS2oqkzq2kgUeAK1m5O3R97029XAmSMOlh4FiGYAHqrZuCJICbpubznqSRFPAG8Aj4OUOwYxg+wezGh/8Alggf9KUlTbn4Gyb+2y3wMjkWm4c7kKK060u571uR29JEgSvAdxkZsA9d33uVVB4ekEA1myELfUbMSsR+ABcl0Q9kzC1LSQFvED5/upsx4PWkfLgpnxuED+2HU4QMZC5wE3iTdNC6nKXhNV0Qtw8A7MRjt8xIxC4a+v8DwlWGtbwBTwp0NzKVNrCJSQ8RrkPN7OF8c3nzYScFi0oNuCZ+eGYP55vKY9CqAl8YBq0AeIx66TXzwCs2D1tgC2yBLbAFtsAW2AJbYAtsgS2wBbbAFtgCW2ALbIEtcNLATs65Bk2BCzkHLpoCHwOO5hj4hCnwWdJ9h2OvEvtKsUP4cshJRd0i8A3h/qWlPFC6vneUcDl3Vgf8IAYY4BfguvhEE/2ew7QgWz/7xQ3j3hKsAad6SgvzhSyCJCBevVz5oZdw08SR/wHw7ZZJBzLcY6h3i+ZdAuCguOS7CUYgwWlMItws4XadvMtpoCabqnfNqALC1f2qpKTnwLc5Ba0SvhN6MwoL8O8AwUvuYBGaCTgAAAAASUVORK5CYII=" alt="FAQ icon" />
    <p>I know what you are thinking...</p>
  </label>
  
  <section id="answer4">
    <p>
      But this wasn't the answer you were looking for.
    </p>
  </section>

</div>
    		<div class="row"> <div class="col-md-6"><p>Note: Commissions calculated on Net Selling Price</p></div>
    		 <div class="col-md-6"><a href="/content.php?action=mypages&amp;page=affiliate-agreement-new.html">View Affiliate Agreement</a></div>
    		</div>
		</div>
	</div>
<style>
    .table-sm tr th,.table-sm tr td{
        padding:20px;
    }
</style>		