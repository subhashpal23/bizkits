<div class="breadcumb-wrapper" data-bg-src="<?php echo base_url();?>frontassets/images/bg.jpg">
            <div class="container">
                <div class="breadcumb-content">
                    <h1 class="breadcumb-title" style="color:#fff;">News Details</h1>
                    <ul class="breadcumb-menu">
                        <li>
                            <a href="<?php echo base_url();?>" style="color:#fff;">Home</a>
                        </li>
                        <li style="color:#fff;">Our Blog</li>
                    </ul>
                </div>
            </div>
        </div>


        <section class="th-blog-wrapper blog-details space-top space-extra-bottom">
            <div class="container">
                <div class="row">
                    <div class="col-xxl-12 col-lg-12">
                        <div class="th-blog blog-single">
                            <div class="blog-img">
                                <img src="<?php echo base_url();?>frontassets/images/blog/4-4.jpg" alt="Blog Image">
                            </div>
                            <div class="blog-content">
                                <div class="blog-meta">
                                    <a class="author" href="<?php echo base_url();?>Web/blog">
                                        <i class="fa-solid fa-user"></i>
                                        By i3 Empire
                                    </a>
                                    <a href="<?php echo base_url();?>Web/blog">
                                        <i class="fa-solid fa-calendar"></i>
                                        1st March, 2024
                                    </a>
                                   
                                </div>
                                <h2 class="blog-title">Breaking Free: i3 Empire Empowers Members to Achieve Financial Independence</h2>
                                <p>Are you ready to break free from financial constraints and pursue true independence? Look no further than i3 Empire, where we're dedicated to empowering our members to achieve financial freedom. Through our comprehensive wealth-building resources, investment opportunities, and educational programs, we provide the tools and support needed to take control of your finances and secure a brighter future. Whether you're looking to pay off debt, build savings, or create passive income streams, i3 Empire is here to guide you every step of the way. Join us as we empower individuals to break free from financial limitations and unlock the path to prosperity.</p>
                               
                                
                                
                                <div class="row mt-15">
                                   
                                </div>
                                
                                <div class="share-links clearfix">
                                    <div class="row justify-content-between">
                                        <div class="col-sm-auto">
                                            
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                       
                           
                            </div>
                        </div>
                    </div>
                   
                        
                             
                            </div>
                        
                              
                          
                                  
                                            
                                        </div>
                                      
                                            
                                            </div>
                                        </div>
                                    </div>
                                
                                          
                                        </div>
                                       
                                             
                                            </div>
                                        </div>
                                    </div>
                                 
                                          
                                        </div>
                                      
                                     
                                            
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                          
                           
                             
                            </div>
                        </aside>
                    </div>
                </div>
            </div>
        </section>