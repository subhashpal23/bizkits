<div class="body-wrapper">
            <div class="bodywrapper__inner">

                <div class="row align-items-center mb-30 justify-content-between">
    <div class="col-lg-6 col-sm-6">
        <h6 class="page-title">Eshop Dashboard</h6>
    </div>
    <div class="col-lg-6 col-sm-6 text-sm-right mt-sm-0 mt-3 right-part">
            
    </div>
</div>
<div class="row mb-none-30">
        
				<?php echo $this->session->flashdata('flash_msg');?>
         <div class="col-sm-6 col-md-3">
            <div class="card card-body bg-silver-400 has-bg-image">
               <div class="media no-margin">
                  <div class="media-body">
                     <h3 class="no-margin"><?php echo $order_data['total_order']; ?></h3>
                     <span class="text-uppercase">Total Order</span>
                  </div>
                  <div class="media-right media-middle">
                     <i class="icon-cart icon-2x opacity-75"></i>
                  </div>
               </div>
            </div>
         </div>
         <div class="col-sm-6 col-md-3">
            <div class="card card-body bg-silver-400 has-bg-image">
               <div class="media no-margin">
                  <div class="media-left media-middle">
                     <i class="icon-cart icon-2x opacity-75"></i>
                  </div>
                  <div class="media-body text-right">
                     <h3 class="no-margin"><?php echo $order_data['pending_order']; ?></h3>
                     <span class="text-uppercase">Total Pending Order</span>
                  </div>
               </div>
            </div>
         </div>
         <div class="col-sm-6 col-md-3">
            <div class="card card-body bg-silver-400 has-bg-image">
               <div class="media no-margin">
                  <div class="media-left media-middle">
                     <i class="icon-cart icon-2x opacity-75"></i>
                  </div>
                  <div class="media-body text-right">
                     <h3 class="no-margin"><?php echo $order_data['confirmed_order']; ?></h3>
                     <span class="text-uppercase">Total Confirmed Order</span>
                  </div>
               </div>
            </div>
         </div>
		 <div class="col-sm-6 col-md-3">
            <div class="card card-body bg-silver-400 has-bg-image">
               <div class="media no-margin">
                  <div class="media-left media-middle">
                     <i class="icon-cart icon-2x opacity-75"></i>
                  </div>
                  <div class="media-body text-right">
                     <h3 class="no-margin"><?php echo $order_data['rejected_order']; ?></h3>
                     <span class="text-uppercase">Total Rejected Order</span>
                  </div>
               </div>
            </div>
         </div>
		 <div class="col-sm-6 col-md-3">
            <div class="card card-body bg-silver-400 has-bg-image">
               <div class="media no-margin">
                  <div class="media-left media-middle">
                     <i class="icon-cart icon-2x opacity-75"></i>
                  </div>
                  <div class="media-body text-right">
                     <h3 class="no-margin"><?php echo $order_data['delivered_order']; ?></h3>
                     <span class="text-uppercase">Total Delivered Order</span>
                  </div>
               </div>
            </div>
         </div>
      </div>
	
    
    
   </div>
   <!-- /content area -->
</div>
<!-- /main content -->