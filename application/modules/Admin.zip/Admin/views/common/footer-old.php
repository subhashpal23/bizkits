</div>
         <!-- /page content -->
      </div>
      <!-- /page container -->
   </body>
</html>
<style type="text/css">
.dropup .dropdown-menu, .navbar-fixed-bottom .dropdown .dropdown-menu {
    margin-bottom: 0px;
}
.dropdown-menu>li {
    margin-bottom: 0px;
}
.dropdown-menu {
    padding: 0px 0;
}
.dropdown-menu>li>a {
    padding: 7px 15px;
}
</style>