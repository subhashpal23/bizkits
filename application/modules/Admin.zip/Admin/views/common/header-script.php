   <head>
      <meta charset="utf-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <title>Admin</title>
      <!-- Global stylesheets -->
      <link href="https://fonts.googleapis.com/css?family=Roboto:400,300,100,500,700,900" rel="stylesheet" type="text/css">
      <link href="<?php echo base_url();?>admin_assets/css/styles.css" rel="stylesheet" type="text/css">
      <link href="<?php echo base_url();?>admin_assets/css/bootstrap.css" rel="stylesheet" type="text/css">
      <link href="<?php echo base_url();?>admin_assets/css/core.css" rel="stylesheet" type="text/css">
      <link href="<?php echo base_url();?>admin_assets/css/components.css" rel="stylesheet" type="text/css">
      <link href="<?php echo base_url();?>admin_assets/assets/css/minified/components.min.css" rel="stylesheet" type="text/css">
      <link href="<?php echo base_url();?>admin_assets/css/colors.css" rel="stylesheet" type="text/css">
      <!-- /global stylesheets -->
      <!-- Core JS files -->
      <script type="text/javascript" src="<?php echo base_url();?>admin_assets/js/pace.min.js"></script>
      <script type="text/javascript" src="<?php echo base_url();?>admin_assets/js/jquery.min.js"></script>
      <script type="text/javascript" src="<?php echo base_url();?>admin_assets/js/bootstrap.min.js"></script>
      <script type="text/javascript" src="<?php echo base_url();?>admin_assets/js/blockui.min.js"></script>
      <!-- /core JS files -->
      <!-- Theme JS files -->
      <script type="text/javascript" src="<?php echo base_url();?>admin_assets/js/d3.min.js"></script>
      <script type="text/javascript" src="<?php echo base_url();?>admin_assets/js/d3_tooltip.js"></script>
      <script type="text/javascript" src="<?php echo base_url();?>admin_assets/js/switchery.min.js"></script>
      <script type="text/javascript" src="<?php echo base_url();?>admin_assets/js/uniform.min.js"></script>
      <script type="text/javascript" src="<?php echo base_url();?>admin_assets/js/bootstrap_multiselect.js"></script>
      <script type="text/javascript" src="<?php echo base_url();?>admin_assets/js/moment.min.js"></script>
      <script type="text/javascript" src="<?php echo base_url();?>admin_assets/js/daterangepicker.js"></script>
      <script type="text/javascript" src="<?php echo base_url();?>admin_assets/js/app.js"></script>
      <script type="text/javascript" src="<?php echo base_url();?>admin_assets/ckeditor/ckeditor.js"></script>
      <script type="text/javascript" src="<?php echo base_url();?>admin_assets/assets/js/plugins/forms/selects/select2.min.js"></script>
      <!-- loader-->
      <script type="text/javascript" src="<?php echo base_url();?>admin_assets/js/jquery.loading.block.js"></script>
      <script type="text/javascript" src="<?php echo base_url();?>admin_assets/js/loader.function.js"></script>
      <!-- validation-->
      <script type="text/javascript" src="<?php echo base_url();?>admin_assets/js/validate.min.js"></script>
      <script type="text/javascript" src="<?php echo base_url();?>admin_assets/js/additional-methods.min.js"></script>
      <script type="text/javascript" src="<?php echo base_url();?>admin_assets/js/client-validation.js"></script>

      <script type="text/javascript" src="<?php echo base_url();?>admin_assets/js/datatables.min.js"></script>
      <script type="text/javascript" src="<?php echo base_url();?>admin_assets/js/datatables_responsive.js"></script>
      <script src="https://js.pusher.com/4.2/pusher.min.js"></script>
      <!-- /theme JS files -->
        <!-- /theme JS files -->
   </head>
